import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { jwtVerify } from "jose"

// This function can be marked `async` if using `await` inside
export async function middleware(request: NextRequest) {
  const token = request.cookies.get("token")?.value

  // If the user is trying to access a protected route without a token, redirect to login
  if (request.nextUrl.pathname.startsWith("/dashboard") && !token) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  // If the user is trying to access a teacher-only route
  if (request.nextUrl.pathname.includes("/create") || request.nextUrl.pathname.startsWith("/dashboard/students")) {
    if (!token) {
      return NextResponse.redirect(new URL("/login", request.url))
    }

    try {
      // Verify the token and check if the user is a teacher
      const secret = new TextEncoder().encode("your_jwt_secret")
      const { payload } = await jwtVerify(token, secret)

      if (payload.role !== "teacher") {
        return NextResponse.redirect(new URL("/dashboard", request.url))
      }
    } catch (error) {
      return NextResponse.redirect(new URL("/login", request.url))
    }
  }

  return NextResponse.next()
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: ["/dashboard/:path*", "/api/:path*"],
}

