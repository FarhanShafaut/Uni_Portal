"use client"

export async function getAnnouncements() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch("/api/announcements", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch announcements")
    }

    const data = await response.json()
    return data.announcements
  } catch (error) {
    console.error("Error fetching announcements:", error)
    return []
  }
}

export async function getCourseAnnouncements(courseId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch(`/api/courses/${courseId}/announcements`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch course announcements")
    }

    const data = await response.json()
    return data.announcements
  } catch (error) {
    console.error("Error fetching course announcements:", error)
    return []
  }
}

export async function getAnnouncementById(announcementId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return null
    }

    const response = await fetch(`/api/announcements/${announcementId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch announcement")
    }

    const data = await response.json()
    return data.announcement
  } catch (error) {
    console.error("Error fetching announcement:", error)
    return null
  }
}

export async function createAnnouncement(courseId: string, content: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/courses/${courseId}/announcements`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ content }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to create announcement" }
    }

    return { success: true, announcementId: data.announcement._id }
  } catch (error) {
    console.error("Error creating announcement:", error)
    return { success: false, message: "An error occurred while creating the announcement" }
  }
}

export async function updateAnnouncement(announcementId: string, content: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/announcements/${announcementId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ content }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to update announcement" }
    }

    return { success: true, announcement: data.announcement }
  } catch (error) {
    console.error("Error updating announcement:", error)
    return { success: false, message: "An error occurred while updating the announcement" }
  }
}

export async function deleteAnnouncement(announcementId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/announcements/${announcementId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to delete announcement" }
    }

    return { success: true }
  } catch (error) {
    console.error("Error deleting announcement:", error)
    return { success: false, message: "An error occurred while deleting the announcement" }
  }
}

