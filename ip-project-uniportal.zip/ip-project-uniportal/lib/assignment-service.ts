"use client"

export async function getUpcomingAssignments() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch("/api/assignments/upcoming", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch upcoming assignments")
    }

    const data = await response.json()
    return data.assignments
  } catch (error) {
    console.error("Error fetching upcoming assignments:", error)
    return []
  }
}

export async function getAllAssignments() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch("/api/assignments", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch assignments")
    }

    const data = await response.json()
    return data.assignments
  } catch (error) {
    console.error("Error fetching assignments:", error)
    return []
  }
}

export async function getCourseAssignments(courseId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch(`/api/courses/${courseId}/assignments`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch course assignments")
    }

    const data = await response.json()
    return data.assignments
  } catch (error) {
    console.error("Error fetching course assignments:", error)
    return []
  }
}

export async function getAssignmentById(assignmentId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return null
    }

    const response = await fetch(`/api/assignments/${assignmentId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch assignment")
    }

    const data = await response.json()
    return data.assignment
  } catch (error) {
    console.error("Error fetching assignment:", error)
    return null
  }
}

export async function createAssignment(courseId: string, title: string, description: string, dueDate: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/courses/${courseId}/assignments`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title, description, dueDate }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to create assignment" }
    }

    return { success: true, assignmentId: data.assignment._id }
  } catch (error) {
    console.error("Error creating assignment:", error)
    return { success: false, message: "An error occurred while creating the assignment" }
  }
}

export async function updateAssignment(assignmentId: string, title: string, description: string, dueDate: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/assignments/${assignmentId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title, description, dueDate }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to update assignment" }
    }

    return { success: true, assignment: data.assignment }
  } catch (error) {
    console.error("Error updating assignment:", error)
    return { success: false, message: "An error occurred while updating the assignment" }
  }
}

export async function deleteAssignment(assignmentId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/assignments/${assignmentId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to delete assignment" }
    }

    return { success: true }
  } catch (error) {
    console.error("Error deleting assignment:", error)
    return { success: false, message: "An error occurred while deleting the assignment" }
  }
}

export async function submitAssignment(assignmentId: string, content: string, files: File[] = []) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const formData = new FormData()
    formData.append("content", content)

    for (const file of files) {
      formData.append("files", file)
    }

    const response = await fetch(`/api/assignments/${assignmentId}/submit`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to submit assignment" }
    }

    return { success: true, submissionId: data.submission._id }
  } catch (error) {
    console.error("Error submitting assignment:", error)
    return { success: false, message: "An error occurred while submitting the assignment" }
  }
}

export async function gradeSubmission(submissionId: string, grade: number, feedback: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/submissions/${submissionId}/grade`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ grade, feedback }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to grade submission" }
    }

    return { success: true, submission: data.submission }
  } catch (error) {
    console.error("Error grading submission:", error)
    return { success: false, message: "An error occurred while grading the submission" }
  }
}

