"use client"

export async function getTeacherStats() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return {
        totalStudents: 0,
        totalCourses: 0,
        totalAssignments: 0,
        pendingGrading: 0,
      }
    }

    const response = await fetch("/api/teachers/stats", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch teacher stats")
    }

    const data = await response.json()
    return data.stats
  } catch (error) {
    console.error("Error fetching teacher stats:", error)
    // Return default values if there's an error
    return {
      totalStudents: 0,
      totalCourses: 0,
      totalAssignments: 0,
      pendingGrading: 0,
    }
  }
}

