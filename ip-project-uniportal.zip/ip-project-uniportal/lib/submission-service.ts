"use client"

export async function getRecentSubmissions() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch("/api/submissions/recent", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch recent submissions")
    }

    const data = await response.json()
    return data.submissions
  } catch (error) {
    console.error("Error fetching recent submissions:", error)
    return []
  }
}

export async function getSubmissionById(submissionId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return null
    }

    const response = await fetch(`/api/submissions/${submissionId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch submission")
    }

    const data = await response.json()
    return data.submission
  } catch (error) {
    console.error("Error fetching submission:", error)
    return null
  }
}

export async function getAssignmentSubmissions(assignmentId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch(`/api/assignments/${assignmentId}/submissions`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch assignment submissions")
    }

    const data = await response.json()
    return data.submissions
  } catch (error) {
    console.error("Error fetching assignment submissions:", error)
    return []
  }
}

export async function getUserSubmissions() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch("/api/submissions/user", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch user submissions")
    }

    const data = await response.json()
    return data.submissions
  } catch (error) {
    console.error("Error fetching user submissions:", error)
    return []
  }
}

