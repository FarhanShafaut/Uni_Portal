"use client"

export async function getStudentStats() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return {
        enrolledCourses: 0,
        completedAssignments: 0,
        pendingAssignments: 0,
        averageGrade: 0,
      }
    }

    const response = await fetch("/api/students/stats", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch student stats")
    }

    const data = await response.json()
    return data.stats
  } catch (error) {
    console.error("Error fetching student stats:", error)
    // Return default values if there's an error
    return {
      enrolledCourses: 0,
      completedAssignments: 0,
      pendingAssignments: 0,
      averageGrade: 0,
    }
  }
}

export async function enrollInCourse(courseId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/courses/${courseId}/enroll`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to enroll in course" }
    }

    return { success: true }
  } catch (error) {
    console.error("Error enrolling in course:", error)
    return { success: false, message: "An error occurred while enrolling in the course" }
  }
}

