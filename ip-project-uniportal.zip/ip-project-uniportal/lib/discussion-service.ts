"use client"

export async function getCourseDiscussions(courseId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch(`/api/courses/${courseId}/discussions`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch discussions")
    }

    const data = await response.json()
    return data.discussions
  } catch (error) {
    console.error("Error fetching discussions:", error)
    return []
  }
}

export async function getAllDiscussions() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch("/api/discussions", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch discussions")
    }

    const data = await response.json()
    return data.discussions
  } catch (error) {
    console.error("Error fetching discussions:", error)
    return []
  }
}

export async function createDiscussion(courseId: string, title: string, content: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/courses/${courseId}/discussions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title, content }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to create discussion" }
    }

    return { success: true, discussionId: data.discussion._id }
  } catch (error) {
    console.error("Error creating discussion:", error)
    return { success: false, message: "An error occurred while creating the discussion" }
  }
}

export async function getDiscussionById(discussionId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return null
    }

    const response = await fetch(`/api/discussions/${discussionId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch discussion")
    }

    const data = await response.json()
    return data.discussion
  } catch (error) {
    console.error("Error fetching discussion:", error)
    return null
  }
}

export async function updateDiscussion(discussionId: string, title: string, content: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/discussions/${discussionId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title, content }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to update discussion" }
    }

    return { success: true, discussion: data.discussion }
  } catch (error) {
    console.error("Error updating discussion:", error)
    return { success: false, message: "An error occurred while updating the discussion" }
  }
}

export async function deleteDiscussion(discussionId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/discussions/${discussionId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to delete discussion" }
    }

    return { success: true }
  } catch (error) {
    console.error("Error deleting discussion:", error)
    return { success: false, message: "An error occurred while deleting the discussion" }
  }
}

export async function addComment(discussionId: string, content: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/discussions/${discussionId}/comments`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ content }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to add comment" }
    }

    return { success: true, comment: data.comment }
  } catch (error) {
    console.error("Error adding comment:", error)
    return { success: false, message: "An error occurred while adding the comment" }
  }
}

export async function deleteComment(discussionId: string, commentId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/discussions/${discussionId}/comments/${commentId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to delete comment" }
    }

    return { success: true }
  } catch (error) {
    console.error("Error deleting comment:", error)
    return { success: false, message: "An error occurred while deleting the comment" }
  }
}

