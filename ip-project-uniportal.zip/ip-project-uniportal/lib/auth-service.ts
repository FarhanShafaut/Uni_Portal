"use client"

export async function loginUser(email: string, password: string) {
  try {
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Login failed" }
    }

    // Store token in localStorage
    localStorage.setItem("token", data.token)

    // Also store user data for easier access
    localStorage.setItem("user", JSON.stringify(data.user))

    return { success: true, user: data.user }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, message: "An error occurred during login" }
  }
}

export async function registerUser(name: string, email: string, password: string, role: string) {
  try {
    const response = await fetch("/api/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, password, role }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Registration failed" }
    }

    return { success: true }
  } catch (error) {
    console.error("Registration error:", error)
    return { success: false, message: "An error occurred during registration" }
  }
}

export async function logoutUser() {
  try {
    // Remove token from localStorage
    localStorage.removeItem("token")
    localStorage.removeItem("user")

    return { success: true }
  } catch (error) {
    console.error("Logout error:", error)
    return { success: false, message: "An error occurred during logout" }
  }
}

export async function getCurrentUser() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "No token found" }
    }

    const response = await fetch("/api/auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      // Clear invalid token
      localStorage.removeItem("token")
      localStorage.removeItem("user")
      return { success: false, message: data.message || "Failed to get current user" }
    }

    // Update stored user data
    localStorage.setItem("user", JSON.stringify(data.user))

    return { success: true, user: data.user }
  } catch (error) {
    console.error("Get current user error:", error)
    return { success: false, message: "An error occurred while getting current user" }
  }
}

export async function updateProfile(name: string, profileImage?: File) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const formData = new FormData()
    formData.append("name", name)

    if (profileImage) {
      formData.append("profileImage", profileImage)
    }

    const response = await fetch("/api/auth/profile", {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to update profile" }
    }

    // Update stored user data
    localStorage.setItem("user", JSON.stringify(data.user))

    return { success: true, user: data.user }
  } catch (error) {
    console.error("Update profile error:", error)
    return { success: false, message: "An error occurred while updating profile" }
  }
}

