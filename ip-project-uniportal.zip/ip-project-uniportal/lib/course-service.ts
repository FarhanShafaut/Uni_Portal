"use client"

export async function getAllCourses() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch("/api/courses", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch courses")
    }

    const data = await response.json()
    return data.courses
  } catch (error) {
    console.error("Error fetching courses:", error)
    return []
  }
}

export async function getUserCourses() {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return []
    }

    const response = await fetch("/api/courses/user", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch user courses")
    }

    const data = await response.json()
    return data.courses
  } catch (error) {
    console.error("Error fetching user courses:", error)
    return []
  }
}

export async function getCourseById(courseId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return null
    }

    const response = await fetch(`/api/courses/${courseId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch course")
    }

    const data = await response.json()
    return data.course
  } catch (error) {
    console.error("Error fetching course:", error)
    return null
  }
}

export async function createCourse(title: string, description: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch("/api/courses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title, description }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to create course" }
    }

    return { success: true, courseId: data.course._id }
  } catch (error) {
    console.error("Error creating course:", error)
    return { success: false, message: "An error occurred while creating the course" }
  }
}

export async function updateCourse(courseId: string, title: string, description: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/courses/${courseId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title, description }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to update course" }
    }

    return { success: true, course: data.course }
  } catch (error) {
    console.error("Error updating course:", error)
    return { success: false, message: "An error occurred while updating the course" }
  }
}

export async function deleteCourse(courseId: string) {
  try {
    const token = localStorage.getItem("token")

    if (!token) {
      return { success: false, message: "Not authenticated" }
    }

    const response = await fetch(`/api/courses/${courseId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Failed to delete course" }
    }

    return { success: true }
  } catch (error) {
    console.error("Error deleting course:", error)
    return { success: false, message: "An error occurred while deleting the course" }
  }
}

