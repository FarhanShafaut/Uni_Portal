import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

// Sample discussion data
const discussions = [
  {
    id: "1",
    title: "Welcome to Introduction to Computer Science",
    course: "Introduction to Computer Science",
    author: "Dr. John Smith",
    date: "October 1, 2023",
    replies: 5,
  },
  {
    id: "2",
    title: "Question about Assignment 1",
    course: "Introduction to Computer Science",
    author: "Jane Student",
    date: "October 5, 2023",
    replies: 3,
  },
  {
    id: "3",
    title: "Study Group for Midterm",
    course: "Advanced Mathematics",
    author: "Mike Johnson",
    date: "October 8, 2023",
    replies: 7,
  },
]

export default function DiscussionsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Discussions</h1>
        <Button>New Discussion</Button>
      </div>

      <div className="space-y-4">
        {discussions.map((discussion) => (
          <Card key={discussion.id}>
            <CardHeader>
              <CardTitle>{discussion.title}</CardTitle>
              <CardDescription>
                Course: {discussion.course} | Posted by {discussion.author} on {discussion.date}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm">{discussion.replies} replies</p>
            </CardContent>
            <CardFooter>
              <Link href={`/dashboard/discussions/${discussion.id}`} className="w-full">
                <Button variant="outline" className="w-full">
                  View Discussion
                </Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

