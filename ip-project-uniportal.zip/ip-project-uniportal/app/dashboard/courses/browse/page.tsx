"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { getAllCourses } from "@/lib/course-service"
import { enrollInCourse } from "@/lib/student-service"
import { Search, BookOpen, Check, Loader2 } from "lucide-react"

export default function BrowseCoursesPage() {
  const { user } = useAuth()
  const [courses, setCourses] = useState([])
  const [filteredCourses, setFilteredCourses] = useState([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [enrollingCourseId, setEnrollingCourseId] = useState(null)

  useEffect(() => {
    async function fetchCourses() {
      try {
        const data = await getAllCourses()
        setCourses(data)
        setFilteredCourses(data)
      } catch (error) {
        console.error("Error fetching courses:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCourses()
  }, [])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredCourses(courses)
    } else {
      const query = searchQuery.toLowerCase()
      setFilteredCourses(
        courses.filter(
          (course) => course.title.toLowerCase().includes(query) || course.description.toLowerCase().includes(query),
        ),
      )
    }
  }, [searchQuery, courses])

  async function handleEnroll(courseId) {
    setEnrollingCourseId(courseId)

    try {
      const result = await enrollInCourse(courseId)

      if (result.success) {
        // Update the courses list to show enrolled status
        setCourses(courses.map((course) => (course._id === courseId ? { ...course, isEnrolled: true } : course)))
      }
    } catch (error) {
      console.error("Error enrolling in course:", error)
    } finally {
      setEnrollingCourseId(null)
    }
  }

  const isEnrolled = (course) => {
    return course.isEnrolled || (course.students && course.students.includes(user?._id))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Browse Courses</h1>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search courses..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {isLoading ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="aspect-video w-full" />
              <CardHeader>
                <Skeleton className="h-6 w-3/4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-10 w-full" />
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : filteredCourses.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No courses found</p>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredCourses.map((course) => (
            <Card key={course._id} className="overflow-hidden">
              <div className="aspect-video w-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                <BookOpen className="h-12 w-12 text-primary/40" />
              </div>
              <CardHeader>
                <CardTitle>{course.title}</CardTitle>
                <CardDescription>Instructor: {course.teacher.name}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground line-clamp-3">{course.description}</p>
              </CardContent>
              <CardFooter>
                {isEnrolled(course) ? (
                  <Button variant="outline" className="w-full" disabled>
                    <Check className="mr-2 h-4 w-4" />
                    Enrolled
                  </Button>
                ) : (
                  <Button
                    className="w-full"
                    onClick={() => handleEnroll(course._id)}
                    disabled={enrollingCourseId === course._id}
                  >
                    {enrollingCourseId === course._id ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Enrolling...
                      </>
                    ) : (
                      "Enroll Now"
                    )}
                  </Button>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

