"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { createCourse } from "@/lib/course-service"

export default function CreateCoursePage() {
  const router = useRouter()
  const { isTeacher, isLoading: authLoading } = useAuth()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  // Redirect if not a teacher
  useEffect(() => {
    if (!authLoading && !isTeacher) {
      router.push("/dashboard")
    }
  }, [isTeacher, authLoading, router])

  async function handleSubmit(event) {
    event.preventDefault()
    setIsLoading(true)
    setError("")

    const formData = new FormData(event.target)
    const title = formData.get("title") as string
    const description = formData.get("description") as string

    try {
      const result = await createCourse(title, description)
      if (result.success) {
        router.push(`/dashboard/courses/${result.courseId}`)
      } else {
        setError(result.message || "Failed to create course. Please try again.")
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  if (authLoading) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!isTeacher) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="mb-6 text-3xl font-bold">Create New Course</h1>

      <Card>
        <CardHeader>
          <CardTitle>Course Details</CardTitle>
          <CardDescription>Enter the information for your new course</CardDescription>
        </CardHeader>
        <CardContent>
          <form id="create-course-form" onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Course Title</Label>
              <Input id="title" name="title" placeholder="Introduction to Computer Science" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Course Description</Label>
              <Textarea
                id="description"
                name="description"
                placeholder="A comprehensive introduction to the fundamental concepts of computer science..."
                rows={5}
                required
              />
            </div>

            {error && <div className="rounded bg-destructive/10 p-2 text-sm text-destructive">{error}</div>}
          </form>
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => router.back()}>
            Cancel
          </Button>
          <Button type="submit" form="create-course-form" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Creating...
              </>
            ) : (
              "Create Course"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

