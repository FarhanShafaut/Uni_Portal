export default function Loading() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="h-10 w-64 mb-2 bg-muted animate-pulse rounded-md"></div>
          <div className="h-5 w-48 bg-muted animate-pulse rounded-md"></div>
        </div>
        <div className="flex gap-2">
          <div className="h-10 w-40 bg-muted animate-pulse rounded-md"></div>
          <div className="h-10 w-40 bg-muted animate-pulse rounded-md"></div>
        </div>
      </div>

      <div className="h-10 w-full max-w-md bg-muted animate-pulse rounded-md"></div>

      <div className="space-y-4">
        <div className="h-40 w-full bg-muted animate-pulse rounded-md"></div>

        <div className="grid gap-4 md:grid-cols-2">
          <div className="h-64 w-full bg-muted animate-pulse rounded-md"></div>
          <div className="h-64 w-full bg-muted animate-pulse rounded-md"></div>
        </div>
      </div>
    </div>
  )
}

