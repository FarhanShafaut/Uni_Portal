"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, ArrowLeft, Trash2 } from "lucide-react"
import { getCourseById, updateCourse, deleteCourse } from "@/lib/course-service"
import { useToast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function EditCoursePage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher, isLoading: authLoading } = useAuth()
  const { toast } = useToast()
  const [course, setCourse] = useState(null)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [error, setError] = useState("")

  const courseId = params.courseId as string

  useEffect(() => {
    async function fetchCourse() {
      try {
        const courseData = await getCourseById(courseId)
        setCourse(courseData)
        setTitle(courseData.title)
        setDescription(courseData.description)
      } catch (error) {
        console.error("Error fetching course:", error)
        toast({
          title: "Error",
          description: "Failed to load course. Please try again.",
          variant: "destructive",
        })
        router.push(`/dashboard/courses/${courseId}`)
      } finally {
        setIsLoading(false)
      }
    }

    if (isTeacher) {
      fetchCourse()
    } else if (!authLoading && !isTeacher) {
      router.push("/dashboard")
    }
  }, [courseId, router, isTeacher, authLoading, toast])

  useEffect(() => {
    // Check if user is the teacher of this course
    if (course && user && course.teacher._id !== user._id) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to edit this course.",
        variant: "destructive",
      })
      router.push(`/dashboard/courses/${courseId}`)
    }
  }, [course, user, courseId, router, toast])

  async function handleSubmit(e) {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    if (!title.trim()) {
      setError("Please enter a title")
      setIsSubmitting(false)
      return
    }

    if (!description.trim()) {
      setError("Please enter a description")
      setIsSubmitting(false)
      return
    }

    try {
      const result = await updateCourse(courseId, title, description)

      if (result.success) {
        toast({
          title: "Course Updated",
          description: "The course has been updated successfully.",
        })
        router.push(`/dashboard/courses/${courseId}`)
      } else {
        setError(result.message || "Failed to update course. Please try again.")
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
      console.error(err)
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleDelete() {
    setIsDeleting(true)

    try {
      const result = await deleteCourse(courseId)

      if (result.success) {
        toast({
          title: "Course Deleted",
          description: "The course has been deleted successfully.",
        })
        router.push("/dashboard/courses")
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to delete course. Please try again.",
          variant: "destructive",
        })
      }
    } catch (err) {
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
      console.error(err)
    } finally {
      setIsDeleting(false)
    }
  }

  if (isLoading || authLoading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!course) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Course Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The course you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push("/dashboard/courses")}>Back to Courses</Button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <Button variant="ghost" className="pl-0 mb-6" onClick={() => router.push(`/dashboard/courses/${courseId}`)}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Course
      </Button>

      <h1 className="text-3xl font-bold mb-6">Edit Course</h1>

      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Course Details</CardTitle>
            <CardDescription>Update your course information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Course Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Introduction to Computer Science"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Course Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="A comprehensive introduction to the fundamental concepts of computer science..."
                rows={5}
                required
              />
            </div>

            {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">{error}</div>}
          </CardContent>
          <CardFooter className="flex justify-between">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" type="button" disabled={isDeleting}>
                  {isDeleting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Deleting...
                    </>
                  ) : (
                    <>
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete Course
                    </>
                  )}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the course and all associated data
                    including assignments, announcements, and discussions.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push(`/dashboard/courses/${courseId}`)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

