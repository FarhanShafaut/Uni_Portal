export default function Loading() {
  return (
    <div className="space-y-6">
      <div className="h-10 w-32 bg-muted animate-pulse rounded-md"></div>
      <div className="h-[300px] w-full bg-muted animate-pulse rounded-md"></div>
    </div>
  )
}

