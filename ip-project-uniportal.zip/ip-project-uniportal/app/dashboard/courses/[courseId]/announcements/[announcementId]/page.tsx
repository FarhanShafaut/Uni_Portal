"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Skeleton } from "@/components/ui/skeleton"
import { ArrowLeft, Edit, Trash2, Loader2 } from "lucide-react"
import { format } from "date-fns"
import { getAnnouncementById, updateAnnouncement, deleteAnnouncement } from "@/lib/announcement-service"
import { useToast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function AnnouncementDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher } = useAuth()
  const { toast } = useToast()
  const [announcement, setAnnouncement] = useState(null)
  const [editContent, setEditContent] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [error, setError] = useState("")

  const courseId = params.courseId as string
  const announcementId = params.announcementId as string

  useEffect(() => {
    async function fetchAnnouncement() {
      try {
        const data = await getAnnouncementById(announcementId)
        setAnnouncement(data)
        setEditContent(data?.content || "")
      } catch (error) {
        console.error("Error fetching announcement:", error)
        toast({
          title: "Error",
          description: "Failed to load announcement. Please try again.",
          variant: "destructive",
        })
        router.push(`/dashboard/courses/${courseId}`)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAnnouncement()
  }, [announcementId, courseId, router, toast])

  async function handleUpdateAnnouncement() {
    if (!editContent.trim()) {
      setError("Content is required")
      return
    }

    setIsSubmitting(true)
    setError("")

    try {
      const result = await updateAnnouncement(announcementId, editContent)

      if (result.success) {
        setAnnouncement({
          ...announcement,
          content: editContent,
          updatedAt: new Date().toISOString(),
        })
        setIsEditDialogOpen(false)
        toast({
          title: "Announcement updated",
          description: "The announcement has been updated successfully.",
        })
      } else {
        setError(result.message || "Failed to update announcement")
      }
    } catch (error) {
      console.error("Error updating announcement:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleDeleteAnnouncement() {
    setIsDeleting(true)

    try {
      const result = await deleteAnnouncement(announcementId)

      if (result.success) {
        toast({
          title: "Announcement deleted",
          description: "The announcement has been deleted successfully.",
        })
        router.push(`/dashboard/courses/${courseId}?tab=announcements`)
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to delete announcement",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error deleting announcement:", error)
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const isOwner = announcement?.createdBy?._id === user?._id

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-32" />
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48 mb-1" />
            <Skeleton className="h-4 w-32" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-3/4" />
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!announcement) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Announcement Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The announcement you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push(`/dashboard/courses/${courseId}`)}>Back to Course</Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Button
        variant="ghost"
        className="pl-0"
        onClick={() => router.push(`/dashboard/courses/${courseId}?tab=announcements`)}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Announcements
      </Button>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>{announcement.course.title} - Announcement</CardTitle>
              <CardDescription>
                Posted by {announcement.createdBy.name} on{" "}
                {format(new Date(announcement.createdAt), "MMM d, yyyy 'at' h:mm a")}
                {announcement.updatedAt && announcement.updatedAt !== announcement.createdAt && (
                  <span> (Edited on {format(new Date(announcement.updatedAt), "MMM d, yyyy 'at' h:mm a")})</span>
                )}
              </CardDescription>
            </div>

            {isOwner && (
              <div className="flex gap-2">
                <DialogTrigger asChild onClick={() => setIsEditDialogOpen(true)}>
                  <Button variant="outline" size="sm">
                    <Edit className="mr-2 h-4 w-4" />
                    Edit
                  </Button>
                </DialogTrigger>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" size="sm">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </Button>
                </AlertDialogTrigger>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm max-w-none dark:prose-invert">
            <p className="whitespace-pre-wrap">{announcement.content}</p>
          </div>
        </CardContent>
      </Card>

      {/* Edit Announcement Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Announcement</DialogTitle>
            <DialogDescription>Make changes to your announcement</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              placeholder="Announcement content"
              rows={8}
            />
            {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">{error}</div>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateAnnouncement} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save changes"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Announcement Alert Dialog */}
      <AlertDialog>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the announcement.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteAnnouncement}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isDeleting}
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

