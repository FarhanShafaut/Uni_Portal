"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, ArrowLeft } from "lucide-react"
import { getCourseById } from "@/lib/course-service"
import { createAnnouncement } from "@/lib/announcement-service"

export default function CreateCourseAnnouncementPage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher } = useAuth()
  const [course, setCourse] = useState(null)
  const [content, setContent] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  const courseId = params.courseId as string

  useEffect(() => {
    async function fetchCourse() {
      try {
        const courseData = await getCourseById(courseId)
        setCourse(courseData)
      } catch (error) {
        console.error("Error fetching course:", error)
        router.push("/dashboard/courses")
      } finally {
        setIsLoading(false)
      }
    }

    if (isTeacher) {
      fetchCourse()
    } else {
      router.push("/dashboard")
    }
  }, [courseId, router, isTeacher])

  useEffect(() => {
    // Check if user is the teacher of this course
    if (course && user && course.teacher._id !== user._id) {
      router.push(`/dashboard/courses/${courseId}`)
    }
  }, [course, user, courseId, router])

  async function handleSubmit(e) {
    e.preventDefault()

    if (!content.trim()) {
      setError("Please enter announcement content")
      return
    }

    setIsSubmitting(true)
    setError("")

    try {
      const result = await createAnnouncement(courseId, content)

      if (result.success) {
        router.push(`/dashboard/courses/${courseId}?tab=announcements`)
      } else {
        setError(result.message || "Failed to create announcement")
      }
    } catch (error) {
      console.error("Error creating announcement:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!course) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Course Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The course you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push("/dashboard/courses")}>Back to Courses</Button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <Button variant="ghost" className="pl-0 mb-6" onClick={() => router.push(`/dashboard/courses/${courseId}`)}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Course
      </Button>

      <h1 className="text-3xl font-bold mb-6">Create Announcement</h1>

      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>New Announcement for {course.title}</CardTitle>
            <CardDescription>Create an announcement for your students</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Enter your announcement here..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={8}
              required
            />

            {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">{error}</div>}
          </CardContent>
          <CardFooter className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                "Post Announcement"
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

