"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"
import { getCourseById } from "@/lib/course-service"
import { createAssignment } from "@/lib/assignment-service"

export default function CreateAssignmentPage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher } = useAuth()
  const [course, setCourse] = useState(null)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [dueDate, setDueDate] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  const courseId = params.courseId as string

  useEffect(() => {
    async function fetchCourse() {
      try {
        const courseData = await getCourseById(courseId)
        setCourse(courseData)

        // Set default due date to 1 week from now
        const oneWeekFromNow = new Date()
        oneWeekFromNow.setDate(oneWeekFromNow.getDate() + 7)
        setDueDate(oneWeekFromNow.toISOString().split("T")[0])
      } catch (error) {
        console.error("Error fetching course:", error)
        router.push("/dashboard/courses")
      } finally {
        setIsLoading(false)
      }
    }

    if (isTeacher) {
      fetchCourse()
    } else {
      router.push("/dashboard")
    }
  }, [courseId, router, isTeacher])

  useEffect(() => {
    // Check if user is the teacher of this course
    if (course && user && course.teacher._id !== user._id) {
      router.push(`/dashboard/courses/${courseId}`)
    }
  }, [course, user, courseId, router])

  async function handleSubmit(e) {
    e.preventDefault()

    if (!title.trim()) {
      setError("Please enter a title")
      return
    }

    if (!description.trim()) {
      setError("Please enter a description")
      return
    }

    if (!dueDate) {
      setError("Please select a due date")
      return
    }

    setIsSubmitting(true)
    setError("")

    try {
      const result = await createAssignment(courseId, title, description, dueDate)

      if (result.success) {
        router.push(`/dashboard/courses/${courseId}/assignments/${result.assignmentId}`)
      } else {
        setError(result.message || "Failed to create assignment")
      }
    } catch (error) {
      console.error("Error creating assignment:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!course) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Course Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The course you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push("/dashboard/courses")}>Back to Courses</Button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Create Assignment</h1>

      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>New Assignment for {course.title}</CardTitle>
            <CardDescription>Create an assignment for your students</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Assignment Title</Label>
              <Input
                id="title"
                placeholder="Enter assignment title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Assignment Description</Label>
              <Textarea
                id="description"
                placeholder="Enter assignment description, instructions, and requirements"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={6}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                required
              />
            </div>

            {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">{error}</div>}
          </CardContent>
          <CardFooter className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                "Create Assignment"
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

