"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { ArrowLeft, Loader2, Save } from "lucide-react"
import { format } from "date-fns"
import { getSubmissionById } from "@/lib/submission-service"
import { gradeSubmission } from "@/lib/assignment-service"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"

export default function SubmissionDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher } = useAuth()
  const { toast } = useToast()
  const [submission, setSubmission] = useState(null)
  const [grade, setGrade] = useState(0)
  const [feedback, setFeedback] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  const courseId = params.courseId as string
  const assignmentId = params.assignmentId as string
  const submissionId = params.submissionId as string

  useEffect(() => {
    async function fetchSubmission() {
      try {
        const data = await getSubmissionById(submissionId)
        setSubmission(data)

        if (data.grade !== null) {
          setGrade(data.grade)
        }

        if (data.feedback) {
          setFeedback(data.feedback)
        }
      } catch (error) {
        console.error("Error fetching submission:", error)
        toast({
          title: "Error",
          description: "Failed to load submission. Please try again.",
          variant: "destructive",
        })
        router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}/submissions`)
      } finally {
        setIsLoading(false)
      }
    }

    if (isTeacher) {
      fetchSubmission()
    } else {
      router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)
    }
  }, [courseId, assignmentId, submissionId, router, isTeacher, toast])

  async function handleSubmit(e) {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    try {
      const result = await gradeSubmission(submissionId, grade, feedback)

      if (result.success) {
        setSubmission({
          ...submission,
          grade,
          feedback,
          gradedAt: new Date().toISOString(),
          gradedBy: user._id,
        })

        toast({
          title: "Submission graded",
          description: "The submission has been graded successfully.",
        })
      } else {
        setError(result.message || "Failed to grade submission")
      }
    } catch (error) {
      console.error("Error grading submission:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!isTeacher) {
    return null // Will redirect in useEffect
  }

  if (isLoading) {
    return <SubmissionDetailSkeleton />
  }

  if (!submission) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Submission Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The submission you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}/submissions`)}>
          Back to Submissions
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Button
        variant="ghost"
        className="pl-0"
        onClick={() => router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}/submissions`)}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Submissions
      </Button>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarImage
                    src={submission.student.profileImage || "/placeholder.svg?height=40&width=40"}
                    alt={submission.student.name}
                  />
                  <AvatarFallback>{submission.student.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle>{submission.student.name}</CardTitle>
                  <CardDescription>
                    Submitted {format(new Date(submission.submittedAt), "MMM d, yyyy 'at' h:mm a")}
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Assignment: {submission.assignment.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Due: {format(new Date(submission.assignment.dueDate), "MMM d, yyyy 'at' h:mm a")}
                  </p>
                </div>
                <div>
                  <h3 className="font-medium mb-2">Submission Content:</h3>
                  <div className="p-4 rounded-md bg-muted">
                    <p className="whitespace-pre-wrap">{submission.content}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <form onSubmit={handleSubmit}>
              <CardHeader>
                <CardTitle>Grade Submission</CardTitle>
                <CardDescription>Provide a grade and feedback for this submission</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="grade">Grade (0-100)</Label>
                    <span className="text-lg font-bold">{grade}%</span>
                  </div>
                  <Slider
                    id="grade"
                    min={0}
                    max={100}
                    step={1}
                    value={[grade]}
                    onValueChange={(value) => setGrade(value[0])}
                    className="py-4"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0%</span>
                    <span>50%</span>
                    <span>100%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="feedback">Feedback</Label>
                  <Textarea
                    id="feedback"
                    placeholder="Provide feedback to the student..."
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    rows={6}
                  />
                </div>

                {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">{error}</div>}

                {submission.gradedAt && (
                  <div className="bg-muted p-3 rounded-md text-sm">
                    <p className="font-medium">Previously graded</p>
                    <p className="text-muted-foreground">
                      Last updated: {format(new Date(submission.gradedAt), "MMM d, yyyy 'at' h:mm a")}
                    </p>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Grade
                    </>
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </div>
    </div>
  )
}

function SubmissionDetailSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-10 w-32" />

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div>
                  <Skeleton className="h-6 w-48 mb-1" />
                  <Skeleton className="h-4 w-32" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Skeleton className="h-6 w-64 mb-2" />
                  <Skeleton className="h-4 w-48 mb-4" />
                </div>
                <div>
                  <Skeleton className="h-5 w-32 mb-2" />
                  <Skeleton className="h-32 w-full rounded-md" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48 mb-1" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-8 w-full" />
              </div>
              <div className="space-y-2">
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-32 w-full" />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Skeleton className="h-10 w-32" />
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

