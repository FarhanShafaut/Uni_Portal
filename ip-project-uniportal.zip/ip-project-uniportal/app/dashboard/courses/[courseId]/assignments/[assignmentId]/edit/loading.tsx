export default function Loading() {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="h-10 w-32 bg-muted animate-pulse rounded-md"></div>
      <div className="h-10 w-64 bg-muted animate-pulse rounded-md"></div>
      <div className="h-[400px] w-full bg-muted animate-pulse rounded-md"></div>
    </div>
  )
}

