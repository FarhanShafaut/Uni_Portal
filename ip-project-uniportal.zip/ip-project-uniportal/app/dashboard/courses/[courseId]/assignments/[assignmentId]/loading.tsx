export default function Loading() {
  return (
    <div className="space-y-6">
      <div className="h-10 w-32 bg-muted animate-pulse rounded-md"></div>

      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="h-10 w-64 mb-2 bg-muted animate-pulse rounded-md"></div>
          <div className="h-5 w-48 bg-muted animate-pulse rounded-md"></div>
        </div>
        <div className="flex gap-2">
          <div className="h-10 w-40 bg-muted animate-pulse rounded-md"></div>
        </div>
      </div>

      <div className="h-16 w-full bg-muted animate-pulse rounded-md"></div>

      <div className="h-[300px] w-full bg-muted animate-pulse rounded-md"></div>

      <div className="h-[200px] w-full bg-muted animate-pulse rounded-md"></div>
    </div>
  )
}

