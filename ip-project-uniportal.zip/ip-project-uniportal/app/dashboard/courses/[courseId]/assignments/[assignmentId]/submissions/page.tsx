"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { ArrowLeft, FileText, Clock } from "lucide-react"
import { format } from "date-fns"
import { getAssignmentById } from "@/lib/assignment-service"
import { getAssignmentSubmissions } from "@/lib/submission-service"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

export default function AssignmentSubmissionsPage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher } = useAuth()
  const { toast } = useToast()
  const [assignment, setAssignment] = useState(null)
  const [submissions, setSubmissions] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  const courseId = params.courseId as string
  const assignmentId = params.assignmentId as string

  useEffect(() => {
    async function fetchData() {
      try {
        const [assignmentData, submissionsData] = await Promise.all([
          getAssignmentById(assignmentId),
          getAssignmentSubmissions(assignmentId),
        ])

        setAssignment(assignmentData)
        setSubmissions(submissionsData)
      } catch (error) {
        console.error("Error fetching assignment submissions:", error)
        toast({
          title: "Error",
          description: "Failed to load submissions. Please try again.",
          variant: "destructive",
        })
        router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)
      } finally {
        setIsLoading(false)
      }
    }

    if (isTeacher) {
      fetchData()
    } else {
      router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)
    }
  }, [courseId, assignmentId, router, isTeacher, toast])

  if (!isTeacher) {
    return null // Will redirect in useEffect
  }

  if (isLoading) {
    return <SubmissionsPageSkeleton />
  }

  if (!assignment) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Assignment Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The assignment you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push(`/dashboard/courses/${courseId}`)}>Back to Course</Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Button
        variant="ghost"
        className="pl-0"
        onClick={() => router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Assignment
      </Button>

      <div>
        <h1 className="text-3xl font-bold">{assignment.title} - Submissions</h1>
        <p className="text-muted-foreground">Due: {format(new Date(assignment.dueDate), "MMM d, yyyy 'at' h:mm a")}</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Student Submissions</CardTitle>
          <CardDescription>
            {submissions.length} {submissions.length === 1 ? "submission" : "submissions"} received
          </CardDescription>
        </CardHeader>
        <CardContent>
          {submissions.length > 0 ? (
            <div className="space-y-4">
              {submissions.map((submission) => (
                <Link
                  key={submission._id}
                  href={`/dashboard/courses/${courseId}/assignments/${assignmentId}/submissions/${submission._id}`}
                >
                  <div className="flex items-center justify-between p-4 rounded-md border hover:border-primary/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage
                          src={submission.student.profileImage || "/placeholder.svg?height=40&width=40"}
                          alt={submission.student.name}
                        />
                        <AvatarFallback>{submission.student.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{submission.student.name}</p>
                        <p className="text-xs text-muted-foreground">
                          Submitted {format(new Date(submission.submittedAt), "MMM d, yyyy 'at' h:mm a")}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {submission.grade !== null ? (
                        <Badge variant={submission.grade >= 60 ? "default" : "destructive"}>{submission.grade}%</Badge>
                      ) : (
                        <Badge variant="outline" className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Needs Grading
                        </Badge>
                      )}
                      <FileText className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No submissions received yet</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function SubmissionsPageSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-10 w-32" />

      <div>
        <Skeleton className="h-10 w-64 mb-2" />
        <Skeleton className="h-5 w-48" />
      </div>

      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48 mb-1" />
          <Skeleton className="h-4 w-32" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

