export default function Loading() {
  return (
    <div className="space-y-6">
      <div className="h-10 w-32 bg-muted animate-pulse rounded-md"></div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-6">
          <div className="h-[200px] w-full bg-muted animate-pulse rounded-md"></div>
        </div>
        <div>
          <div className="h-[400px] w-full bg-muted animate-pulse rounded-md"></div>
        </div>
      </div>
    </div>
  )
}

