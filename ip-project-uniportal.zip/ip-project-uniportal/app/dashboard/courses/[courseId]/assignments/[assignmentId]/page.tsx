"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Skeleton } from "@/components/ui/skeleton"
import { Loader2, ArrowLeft, Calendar, Users, Edit, Trash2 } from "lucide-react"
import { format } from "date-fns"
import { getAssignmentById, submitAssignment, deleteAssignment } from "@/lib/assignment-service"
import { useToast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function AssignmentDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher, isStudent } = useAuth()
  const { toast } = useToast()
  const [assignment, setAssignment] = useState(null)
  const [submission, setSubmission] = useState(null)
  const [submissionContent, setSubmissionContent] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [error, setError] = useState("")

  const courseId = params.courseId as string
  const assignmentId = params.assignmentId as string

  useEffect(() => {
    async function fetchAssignment() {
      try {
        const data = await getAssignmentById(assignmentId)
        setAssignment(data)

        if (data.submission) {
          setSubmission(data.submission)
          setSubmissionContent(data.submission.content)
        }
      } catch (error) {
        console.error("Error fetching assignment:", error)
        toast({
          title: "Error",
          description: "Failed to load assignment. Please try again.",
          variant: "destructive",
        })
        router.push(`/dashboard/courses/${courseId}`)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAssignment()
  }, [assignmentId, courseId, router, toast])

  async function handleSubmit(e) {
    e.preventDefault()

    if (!submissionContent.trim()) {
      setError("Please enter your submission")
      return
    }

    setIsSubmitting(true)
    setError("")

    try {
      const result = await submitAssignment(assignmentId, submissionContent, [])

      if (result.success) {
        setSubmission({
          _id: result.submissionId,
          content: submissionContent,
          submittedAt: new Date().toISOString(),
          grade: null,
          feedback: null,
        })

        toast({
          title: "Assignment submitted",
          description: "Your assignment has been submitted successfully.",
        })
      } else {
        setError(result.message || "Failed to submit assignment")
      }
    } catch (error) {
      console.error("Error submitting assignment:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleDeleteAssignment() {
    setIsDeleting(true)

    try {
      const result = await deleteAssignment(assignmentId)

      if (result.success) {
        toast({
          title: "Assignment deleted",
          description: "The assignment has been deleted successfully.",
        })
        router.push(`/dashboard/courses/${courseId}`)
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to delete assignment",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error deleting assignment:", error)
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const isPastDue = assignment && new Date(assignment.dueDate) < new Date()
  const canSubmit = isStudent && !isPastDue && !submission
  const isTeacherOfCourse = isTeacher && assignment?.course?.teacher?._id === user?._id

  if (isLoading) {
    return <AssignmentDetailSkeleton />
  }

  if (!assignment) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Assignment Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The assignment you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push(`/dashboard/courses/${courseId}`)}>Back to Course</Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Button variant="ghost" className="pl-0 mb-2" onClick={() => router.push(`/dashboard/courses/${courseId}`)}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Course
      </Button>

      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">{assignment.title}</h1>
          <p className="text-muted-foreground">{assignment.course.title}</p>
        </div>

        {isTeacherOfCourse && (
          <div className="flex gap-2">
            <Link href={`/dashboard/courses/${courseId}/assignments/${assignmentId}/edit`}>
              <Button variant="outline">
                <Edit className="mr-2 h-4 w-4" />
                Edit
              </Button>
            </Link>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the assignment and all associated
                    submissions.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDeleteAssignment}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    disabled={isDeleting}
                  >
                    {isDeleting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Deleting...
                      </>
                    ) : (
                      "Delete"
                    )}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 px-4 py-2 rounded-md bg-muted">
        <Calendar className="h-5 w-5 text-primary" />
        <div>
          <p className="text-sm font-medium">Due Date</p>
          <p className={`text-sm ${isPastDue ? "text-destructive" : "text-muted-foreground"}`}>
            {format(new Date(assignment.dueDate), "MMM d, yyyy 'at' h:mm a")}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Assignment Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm max-w-none">
            <p className="whitespace-pre-wrap">{assignment.description}</p>
          </div>
        </CardContent>
        {isTeacherOfCourse && (
          <CardFooter>
            <Link href={`/dashboard/courses/${courseId}/assignments/${assignmentId}/submissions`}>
              <Button>
                <Users className="mr-2 h-4 w-4" />
                View Submissions
              </Button>
            </Link>
          </CardFooter>
        )}
      </Card>

      {submission ? (
        <Card>
          <CardHeader>
            <CardTitle>Your Submission</CardTitle>
            <CardDescription>
              Submitted on {format(new Date(submission.submittedAt), "MMM d, yyyy 'at' h:mm a")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm max-w-none">
              <p className="whitespace-pre-wrap">{submission.content}</p>
            </div>

            {submission.grade !== null && (
              <div className="mt-6 p-4 rounded-md bg-muted">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-semibold">Grade</h3>
                  <span className="text-lg font-bold">{submission.grade}%</span>
                </div>
                {submission.feedback && (
                  <div>
                    <h4 className="font-medium mb-1">Feedback</h4>
                    <p className="text-sm">{submission.feedback}</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      ) : canSubmit ? (
        <Card>
          <form onSubmit={handleSubmit}>
            <CardHeader>
              <CardTitle>Submit Assignment</CardTitle>
              <CardDescription>Enter your submission below</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Enter your submission here..."
                value={submissionContent}
                onChange={(e) => setSubmissionContent(e.target.value)}
                rows={8}
                required
              />

              {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded mt-4">{error}</div>}
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  "Submit Assignment"
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>
      ) : isPastDue ? (
        <Card>
          <CardHeader>
            <CardTitle>Assignment Closed</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">This assignment is past due and no longer accepting submissions.</p>
          </CardContent>
        </Card>
      ) : null}
    </div>
  )
}

function AssignmentDetailSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-10 w-32" />

      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <Skeleton className="h-10 w-64 mb-2" />
          <Skeleton className="h-5 w-48" />
        </div>
        <Skeleton className="h-16 w-48" />
      </div>

      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-3/4" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-32 w-full" />
        </CardContent>
        <CardFooter>
          <Skeleton className="h-10 w-32 ml-auto" />
        </CardFooter>
      </Card>
    </div>
  )
}

