"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, ArrowLeft } from "lucide-react"
import { getAssignmentById, updateAssignment } from "@/lib/assignment-service"
import { useToast } from "@/hooks/use-toast"

export default function EditAssignmentPage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher } = useAuth()
  const { toast } = useToast()
  const [assignment, setAssignment] = useState(null)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [dueDate, setDueDate] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  const courseId = params.courseId as string
  const assignmentId = params.assignmentId as string

  useEffect(() => {
    async function fetchAssignment() {
      try {
        const assignmentData = await getAssignmentById(assignmentId)
        setAssignment(assignmentData)

        if (assignmentData) {
          setTitle(assignmentData.title)
          setDescription(assignmentData.description)

          // Format the date for the input field (YYYY-MM-DD)
          const date = new Date(assignmentData.dueDate)
          setDueDate(date.toISOString().split("T")[0])
        }
      } catch (error) {
        console.error("Error fetching assignment:", error)
        toast({
          title: "Error",
          description: "Failed to load assignment. Please try again.",
          variant: "destructive",
        })
        router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)
      } finally {
        setIsLoading(false)
      }
    }

    if (isTeacher) {
      fetchAssignment()
    } else {
      router.push(`/dashboard/courses/${courseId}`)
    }
  }, [assignmentId, courseId, router, isTeacher, toast])

  useEffect(() => {
    // Check if user is the teacher of this course
    if (assignment && user && assignment.course.teacher._id !== user._id) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to edit this assignment.",
        variant: "destructive",
      })
      router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)
    }
  }, [assignment, user, courseId, assignmentId, router, toast])

  async function handleSubmit(e) {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    if (!title.trim()) {
      setError("Please enter a title")
      setIsSubmitting(false)
      return
    }

    if (!description.trim()) {
      setError("Please enter a description")
      setIsSubmitting(false)
      return
    }

    if (!dueDate) {
      setError("Please select a due date")
      setIsSubmitting(false)
      return
    }

    try {
      const result = await updateAssignment(assignmentId, title, description, dueDate)

      if (result.success) {
        toast({
          title: "Assignment Updated",
          description: "The assignment has been updated successfully.",
        })
        router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)
      } else {
        setError(result.message || "Failed to update assignment. Please try again.")
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
      console.error(err)
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!isTeacher) {
    return null // Will redirect in useEffect
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!assignment) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Assignment Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The assignment you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push(`/dashboard/courses/${courseId}`)}>Back to Course</Button>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <Button
        variant="ghost"
        className="pl-0 mb-6"
        onClick={() => router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Assignment
      </Button>

      <h1 className="text-3xl font-bold mb-6">Edit Assignment</h1>

      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Assignment Details</CardTitle>
            <CardDescription>Update your assignment information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Assignment Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Introduction to Computer Science"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Assignment Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="A comprehensive introduction to the fundamental concepts of computer science..."
                rows={5}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                required
              />
            </div>

            {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">{error}</div>}
          </CardContent>
          <CardFooter className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.push(`/dashboard/courses/${courseId}/assignments/${assignmentId}`)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

