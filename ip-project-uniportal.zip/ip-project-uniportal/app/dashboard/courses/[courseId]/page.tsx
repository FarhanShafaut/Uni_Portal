"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { getCourseById } from "@/lib/course-service"
import { getCourseAnnouncements } from "@/lib/announcement-service"
import { getCourseAssignments } from "@/lib/assignment-service"
import { getCourseDiscussions } from "@/lib/discussion-service"
import { format } from "date-fns"
import { MessageSquare, Users, Plus, Calendar, Edit } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"

export default function CourseDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user, isTeacher } = useAuth()
  const { toast } = useToast()
  const [course, setCourse] = useState(null)
  const [announcements, setAnnouncements] = useState([])
  const [assignments, setAssignments] = useState([])
  const [discussions, setDiscussions] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")

  const courseId = params.courseId as string

  // Get tab from URL if present
  useEffect(() => {
    // Check if we're in a browser environment
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search)
      const tab = urlParams.get("tab")
      if (tab && ["overview", "announcements", "assignments", "discussions", "students"].includes(tab)) {
        setActiveTab(tab)
      }
    }
  }, [])

  // Handle tab changes
  const handleTabChange = (value) => {
    setActiveTab(value)
    // Update URL without full navigation
    const url = new URL(window.location.href)
    url.searchParams.set("tab", value)
    window.history.pushState({}, "", url)
  }

  useEffect(() => {
    async function fetchCourseData() {
      try {
        const [courseData, announcementsData, assignmentsData, discussionsData] = await Promise.all([
          getCourseById(courseId),
          getCourseAnnouncements(courseId),
          getCourseAssignments(courseId),
          getCourseDiscussions(courseId),
        ])

        setCourse(courseData)
        setAnnouncements(announcementsData)
        setAssignments(assignmentsData)
        setDiscussions(discussionsData)
      } catch (error) {
        console.error("Error fetching course data:", error)
        toast({
          title: "Error",
          description: "Failed to load course data. Please try again.",
          variant: "destructive",
        })
        router.push("/dashboard/courses")
      } finally {
        setIsLoading(false)
      }
    }

    fetchCourseData()
  }, [courseId, router, toast])

  if (isLoading) {
    return <CourseDetailSkeleton />
  }

  if (!course) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <h1 className="text-2xl font-bold mb-4">Course Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The course you're looking for doesn't exist or you don't have access to it.
        </p>
        <Link href="/dashboard/courses">
          <Button>Back to Courses</Button>
        </Link>
      </div>
    )
  }

  const isTeacherOfCourse = isTeacher && user?._id === course.teacher._id

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">{course.title}</h1>
          <p className="text-muted-foreground">Instructor: {course.teacher.name}</p>
        </div>

        {isTeacherOfCourse && (
          <div className="flex gap-2">
            <Link href={`/dashboard/courses/${courseId}/edit`}>
              <Button variant="outline">
                <Edit className="mr-2 h-4 w-4" />
                Edit Course
              </Button>
            </Link>
            <Link href={`/dashboard/courses/${courseId}/announcements/create`}>
              <Button variant="outline">
                <MessageSquare className="mr-2 h-4 w-4" />
                Post Announcement
              </Button>
            </Link>
            <Link href={`/dashboard/courses/${courseId}/assignments/create`}>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Assignment
              </Button>
            </Link>
          </div>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="announcements">Announcements</TabsTrigger>
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
          <TabsTrigger value="discussions">Discussions</TabsTrigger>
          {isTeacherOfCourse && <TabsTrigger value="students">Students</TabsTrigger>}
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Course Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{course.description}</p>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Recent Announcements</CardTitle>
              </CardHeader>
              <CardContent>
                {announcements.length > 0 ? (
                  <div className="space-y-2">
                    {announcements.slice(0, 3).map((announcement) => (
                      <Link
                        key={announcement._id}
                        href={`/dashboard/courses/${courseId}/announcements/${announcement._id}`}
                        className="block"
                      >
                        <div className="p-3 rounded-md border hover:border-primary/50 transition-colors">
                          <div className="flex justify-between items-start mb-1">
                            <p className="text-sm font-medium">{announcement.createdBy.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(announcement.createdAt), "MMM d, yyyy")}
                            </p>
                          </div>
                          <p className="text-sm line-clamp-2">{announcement.content}</p>
                        </div>
                      </Link>
                    ))}
                    {announcements.length > 3 && (
                      <Button variant="link" className="p-0 h-auto" onClick={() => handleTabChange("announcements")}>
                        View all announcements
                      </Button>
                    )}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-4">No announcements yet</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Upcoming Assignments</CardTitle>
              </CardHeader>
              <CardContent>
                {assignments.length > 0 ? (
                  <div className="space-y-2">
                    {assignments
                      .filter((a) => new Date(a.dueDate) > new Date())
                      .slice(0, 3)
                      .map((assignment) => (
                        <Link
                          key={assignment._id}
                          href={`/dashboard/courses/${courseId}/assignments/${assignment._id}`}
                          className="flex items-center p-2 rounded-md hover:bg-muted"
                        >
                          <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center mr-3">
                            <Calendar className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{assignment.title}</p>
                            <p className="text-xs text-amber-600">
                              Due {format(new Date(assignment.dueDate), "MMM d, yyyy")}
                            </p>
                          </div>
                        </Link>
                      ))}
                    {assignments.length > 3 && (
                      <Button variant="link" className="p-0 h-auto" onClick={() => handleTabChange("assignments")}>
                        View all assignments
                      </Button>
                    )}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-4">No assignments yet</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="announcements">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Announcements</CardTitle>
                <CardDescription>All announcements for this course</CardDescription>
              </div>
              {isTeacherOfCourse && (
                <Link href={`/dashboard/courses/${courseId}/announcements/create`}>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Post Announcement
                  </Button>
                </Link>
              )}
            </CardHeader>
            <CardContent>
              {announcements.length > 0 ? (
                <div className="space-y-4">
                  {announcements.map((announcement) => (
                    <Link
                      key={announcement._id}
                      href={`/dashboard/courses/${courseId}/announcements/${announcement._id}`}
                      className="block"
                    >
                      <div className="p-4 rounded-md border hover:border-primary/50 transition-colors">
                        <div className="flex justify-between items-start mb-2">
                          <p className="font-medium">{announcement.createdBy.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(announcement.createdAt), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                        </div>
                        <p className="whitespace-pre-wrap line-clamp-3">{announcement.content}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">No announcements yet</p>
                  {isTeacherOfCourse && (
                    <Link href={`/dashboard/courses/${courseId}/announcements/create`}>
                      <Button>Create your first announcement</Button>
                    </Link>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assignments">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Assignments</CardTitle>
                <CardDescription>All assignments for this course</CardDescription>
              </div>
              {isTeacherOfCourse && (
                <Link href={`/dashboard/courses/${courseId}/assignments/create`}>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Assignment
                  </Button>
                </Link>
              )}
            </CardHeader>
            <CardContent>
              {assignments.length > 0 ? (
                <div className="space-y-4">
                  {assignments.map((assignment) => (
                    <Link
                      key={assignment._id}
                      href={`/dashboard/courses/${courseId}/assignments/${assignment._id}`}
                      className="block p-4 rounded-md border hover:border-primary/50 transition-colors"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-medium text-lg">{assignment.title}</p>
                          <p className="text-sm text-muted-foreground">
                            Posted on {format(new Date(assignment.createdAt), "MMM d, yyyy")}
                          </p>
                        </div>
                        <div className="text-right">
                          <p
                            className={`text-sm font-medium ${
                              new Date(assignment.dueDate) < new Date() ? "text-destructive" : "text-amber-600"
                            }`}
                          >
                            Due {format(new Date(assignment.dueDate), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                          {assignment.submission && <p className="text-xs text-green-600 mt-1">Submitted</p>}
                        </div>
                      </div>
                      <p className="text-sm line-clamp-2">{assignment.description}</p>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">No assignments yet</p>
                  {isTeacherOfCourse && (
                    <Link href={`/dashboard/courses/${courseId}/assignments/create`}>
                      <Button>Create your first assignment</Button>
                    </Link>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="discussions">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Discussions</CardTitle>
                <CardDescription>Join conversations and ask questions</CardDescription>
              </div>
              <Link href={`/dashboard/courses/${courseId}/discussions/create`}>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  New Discussion
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {discussions && discussions.length > 0 ? (
                <div className="space-y-4">
                  {discussions.map((discussion) => (
                    <Link
                      key={discussion._id}
                      href={`/dashboard/courses/${courseId}/discussions/${discussion._id}`}
                      className="block"
                    >
                      <div className="p-4 rounded-md border hover:border-primary/50 transition-colors">
                        <div className="flex justify-between items-start mb-2">
                          <div className="font-medium">{discussion.title}</div>
                          <div className="text-xs text-muted-foreground">
                            {format(new Date(discussion.createdAt), "MMM d, yyyy")}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                          <Avatar className="h-5 w-5">
                            <AvatarImage
                              src={discussion.createdBy.profileImage || "/placeholder.svg?height=20&width=20"}
                              alt={discussion.createdBy.name}
                            />
                            <AvatarFallback className="text-xs">{discussion.createdBy.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span>{discussion.createdBy.name}</span>
                        </div>
                        <p className="text-sm line-clamp-2">{discussion.content}</p>
                        <div className="flex items-center text-xs text-muted-foreground mt-2">
                          <MessageSquare className="h-3 w-3 mr-1" />
                          {discussion.comments?.length || 0} comments
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h2 className="text-xl font-semibold mb-2">No discussions yet</h2>
                  <p className="text-muted-foreground mb-6">Start a discussion to ask questions or share ideas.</p>
                  <Link href={`/dashboard/courses/${courseId}/discussions/create`}>
                    <Button>Start a Discussion</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {isTeacherOfCourse && (
          <TabsContent value="students">
            <Card>
              <CardHeader>
                <CardTitle>Enrolled Students</CardTitle>
                <CardDescription>Students enrolled in this course</CardDescription>
              </CardHeader>
              <CardContent>
                {course.students && course.students.length > 0 ? (
                  <div className="space-y-2">
                    {course.students.map((student) => (
                      <div key={student._id} className="flex items-center p-2 rounded-md hover:bg-muted">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                          <Users className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{student.name}</p>
                          <p className="text-xs text-muted-foreground">{student.email}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-4">No students enrolled yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}

function CourseDetailSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <Skeleton className="h-10 w-64 mb-2" />
          <Skeleton className="h-5 w-48" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-10 w-40" />
          <Skeleton className="h-10 w-40" />
        </div>
      </div>

      <Skeleton className="h-10 w-full max-w-md" />

      <div className="space-y-4">
        <Skeleton className="h-40 w-full" />

        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    </div>
  )
}

