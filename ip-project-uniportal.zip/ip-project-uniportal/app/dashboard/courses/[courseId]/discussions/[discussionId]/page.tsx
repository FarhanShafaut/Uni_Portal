"use client"

import { useState, useEffect, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Skeleton } from "@/components/ui/skeleton"
import { Loader2, ArrowLeft, MessageSquare, Send, MoreVertical, Edit, Trash2 } from "lucide-react"
import { format } from "date-fns"
import {
  getDiscussionById,
  addComment,
  deleteComment,
  updateDiscussion,
  deleteDiscussion,
} from "@/lib/discussion-service"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function DiscussionDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [discussion, setDiscussion] = useState(null)
  const [comment, setComment] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [error, setError] = useState("")
  const [editTitle, setEditTitle] = useState("")
  const [editContent, setEditContent] = useState("")
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const commentsEndRef = useRef(null)

  const courseId = params.courseId as string
  const discussionId = params.discussionId as string

  useEffect(() => {
    async function fetchDiscussion() {
      try {
        const data = await getDiscussionById(discussionId)
        setDiscussion(data)
        setEditTitle(data?.title || "")
        setEditContent(data?.content || "")
      } catch (error) {
        console.error("Error fetching discussion:", error)
        toast({
          title: "Error",
          description: "Failed to load discussion. Please try again.",
          variant: "destructive",
        })
        router.push(`/dashboard/courses/${courseId}/discussions`)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDiscussion()

    // Poll for new comments every 10 seconds
    const interval = setInterval(fetchDiscussion, 10000)

    return () => clearInterval(interval)
  }, [discussionId, courseId, router, toast])

  useEffect(() => {
    // Scroll to bottom when new comments are added
    if (commentsEndRef.current) {
      commentsEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [discussion?.comments?.length])

  async function handleSubmitComment(e) {
    e.preventDefault()

    if (!comment.trim()) {
      setError("Please enter a comment")
      return
    }

    setIsSubmitting(true)
    setError("")

    try {
      const result = await addComment(discussionId, comment)

      if (result.success) {
        setComment("")
        // Update the discussion with the new comment
        setDiscussion({
          ...discussion,
          comments: [...discussion.comments, result.comment],
        })
        toast({
          title: "Comment added",
          description: "Your comment has been added to the discussion.",
        })
      } else {
        setError(result.message || "Failed to add comment")
      }
    } catch (error) {
      console.error("Error adding comment:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleDeleteComment(commentId) {
    try {
      const result = await deleteComment(discussionId, commentId)

      if (result.success) {
        // Update the discussion by removing the deleted comment
        setDiscussion({
          ...discussion,
          comments: discussion.comments.filter((comment) => comment._id !== commentId),
        })
        toast({
          title: "Comment deleted",
          description: "Your comment has been deleted.",
        })
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to delete comment",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error deleting comment:", error)
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
    }
  }

  async function handleUpdateDiscussion() {
    if (!editTitle.trim() || !editContent.trim()) {
      toast({
        title: "Error",
        description: "Title and content are required",
        variant: "destructive",
      })
      return
    }

    try {
      const result = await updateDiscussion(discussionId, editTitle, editContent)

      if (result.success) {
        setDiscussion({
          ...discussion,
          title: editTitle,
          content: editContent,
        })
        setIsEditDialogOpen(false)
        toast({
          title: "Discussion updated",
          description: "Your discussion has been updated successfully.",
        })
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to update discussion",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error updating discussion:", error)
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
    }
  }

  async function handleDeleteDiscussion() {
    setIsDeleting(true)

    try {
      const result = await deleteDiscussion(discussionId)

      if (result.success) {
        toast({
          title: "Discussion deleted",
          description: "The discussion has been deleted successfully.",
        })
        router.push(`/dashboard/courses/${courseId}/discussions`)
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to delete discussion",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error deleting discussion:", error)
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  const isOwner = discussion?.createdBy?._id === user?._id

  if (isLoading) {
    return <DiscussionDetailSkeleton />
  }

  if (!discussion) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Discussion Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The discussion you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push(`/dashboard/courses/${courseId}/discussions`)}>Back to Discussions</Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Button
        variant="ghost"
        className="pl-0"
        onClick={() => router.push(`/dashboard/courses/${courseId}/discussions`)}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Discussions
      </Button>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl">{discussion.title}</CardTitle>
              <CardDescription className="flex items-center gap-2 mt-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage
                    src={discussion.createdBy.profileImage || "/placeholder.svg?height=24&width=24"}
                    alt={discussion.createdBy.name}
                  />
                  <AvatarFallback className="text-xs">{discussion.createdBy.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <span>{discussion.createdBy.name}</span>
                <span className="text-xs px-1.5 py-0.5 rounded-full bg-primary/10">
                  {discussion.createdBy.role === "teacher" ? "Teacher" : "Student"}
                </span>
                <span>•</span>
                <span>{format(new Date(discussion.createdAt), "MMM d, yyyy 'at' h:mm a")}</span>
              </CardDescription>
            </div>

            {isOwner && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DialogTrigger asChild onClick={() => setIsEditDialogOpen(true)}>
                    <DropdownMenuItem>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </DropdownMenuItem>
                  </DialogTrigger>
                  <AlertDialogTrigger asChild>
                    <DropdownMenuItem className="text-destructive">
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete
                    </DropdownMenuItem>
                  </AlertDialogTrigger>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm max-w-none dark:prose-invert">
            <p className="whitespace-pre-wrap">{discussion.content}</p>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          <h2 className="text-xl font-semibold">Comments ({discussion.comments?.length || 0})</h2>
        </div>

        <div className="space-y-4 max-h-[500px] overflow-y-auto p-1">
          {discussion.comments?.length > 0 ? (
            discussion.comments.map((comment) => (
              <Card key={comment._id} className={comment.createdBy._id === user?._id ? "border-primary/30" : ""}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage
                          src={comment.createdBy.profileImage || "/placeholder.svg?height=32&width=32"}
                          alt={comment.createdBy.name}
                        />
                        <AvatarFallback>{comment.createdBy.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{comment.createdBy.name}</span>
                          <span className="text-xs px-1.5 py-0.5 rounded-full bg-primary/10">
                            {comment.createdBy.role === "teacher" ? "Teacher" : "Student"}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(comment.createdAt), "MMM d, yyyy 'at' h:mm a")}
                        </p>
                      </div>
                    </div>

                    {comment.createdBy._id === user?._id && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteComment(comment._id)}
                        className="h-8 w-8"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="whitespace-pre-wrap">{comment.content}</p>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No comments yet. Be the first to comment!</p>
            </div>
          )}
          <div ref={commentsEndRef} />
        </div>

        <Card>
          <form onSubmit={handleSubmitComment}>
            <CardHeader>
              <CardTitle className="text-lg">Add a Comment</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Textarea
                  placeholder="Write your comment here..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={3}
                  required
                />

                {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">{error}</div>}
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Posting...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Post Comment
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>

      {/* Edit Discussion Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Discussion</DialogTitle>
            <DialogDescription>Make changes to your discussion</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-title">Title</Label>
              <Input
                id="edit-title"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="Discussion title"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-content">Content</Label>
              <Textarea
                id="edit-content"
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                placeholder="Discussion content"
                rows={6}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateDiscussion}>Save changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Discussion Alert Dialog */}
      <AlertDialog>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the discussion and all its comments.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteDiscussion}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isDeleting}
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function DiscussionDetailSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-10 w-32" />

      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <Skeleton className="h-8 w-64 mb-2" />
              <div className="flex items-center gap-2">
                <Skeleton className="h-6 w-6 rounded-full" />
                <Skeleton className="h-4 w-32" />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-3/4" />
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Skeleton className="h-5 w-5" />
          <Skeleton className="h-6 w-32" />
        </div>

        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-32 mb-1" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-3/4" />
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-24 w-full" />
          </CardContent>
          <CardFooter className="flex justify-end">
            <Skeleton className="h-10 w-32" />
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

