"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Input } from "@/components/ui/input"
import { getCourseById } from "@/lib/course-service"
import { getCourseDiscussions } from "@/lib/discussion-service"
import { format } from "date-fns"
import { MessageSquare, Plus, ArrowLeft, Search } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"

export default function CourseDiscussionsPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [course, setCourse] = useState(null)
  const [discussions, setDiscussions] = useState([])
  const [filteredDiscussions, setFilteredDiscussions] = useState([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  const courseId = params.courseId as string

  useEffect(() => {
    async function fetchData() {
      try {
        const [courseData, discussionsData] = await Promise.all([
          getCourseById(courseId),
          getCourseDiscussions(courseId),
        ])

        setCourse(courseData)
        setDiscussions(discussionsData)
        setFilteredDiscussions(discussionsData)
      } catch (error) {
        console.error("Error fetching course discussions:", error)
        toast({
          title: "Error",
          description: "Failed to load discussions. Please try again.",
          variant: "destructive",
        })
        router.push(`/dashboard/courses/${courseId}`)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [courseId, router, toast])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredDiscussions(discussions)
    } else {
      const query = searchQuery.toLowerCase()
      setFilteredDiscussions(
        discussions.filter(
          (discussion) =>
            discussion.title.toLowerCase().includes(query) ||
            discussion.content.toLowerCase().includes(query) ||
            discussion.createdBy.name.toLowerCase().includes(query),
        ),
      )
    }
  }, [searchQuery, discussions])

  if (isLoading) {
    return <DiscussionsPageSkeleton />
  }

  if (!course) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Course Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The course you're looking for doesn't exist or you don't have access to it.
        </p>
        <Button onClick={() => router.push("/dashboard/courses")}>Back to Courses</Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => router.push(`/dashboard/courses/${courseId}`)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-bold">{course.title} - Discussions</h1>
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search discussions..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Link href={`/dashboard/courses/${courseId}/discussions/create`}>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Discussion
          </Button>
        </Link>
      </div>

      {filteredDiscussions.length > 0 ? (
        <div className="space-y-4">
          {filteredDiscussions.map((discussion) => (
            <Link key={discussion._id} href={`/dashboard/courses/${courseId}/discussions/${discussion._id}`}>
              <Card className="hover:border-primary/50 transition-colors">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-xl">{discussion.title}</CardTitle>
                    <div className="text-sm text-muted-foreground">
                      {format(new Date(discussion.createdAt), "MMM d, yyyy")}
                    </div>
                  </div>
                  <CardDescription className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage
                        src={discussion.createdBy.profileImage || "/placeholder.svg?height=24&width=24"}
                        alt={discussion.createdBy.name}
                      />
                      <AvatarFallback className="text-xs">{discussion.createdBy.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span>{discussion.createdBy.name}</span>
                    <span className="text-xs px-1.5 py-0.5 rounded-full bg-primary/10">
                      {discussion.createdBy.role === "teacher" ? "Teacher" : "Student"}
                    </span>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="line-clamp-2">{discussion.content}</p>
                </CardContent>
                <CardFooter>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <MessageSquare className="h-4 w-4 mr-1" />
                    {discussion.comments?.length || 0} comments
                  </div>
                </CardFooter>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">No discussions yet</h2>
          <p className="text-muted-foreground mb-6">Be the first to start a discussion in this course.</p>
          <Link href={`/dashboard/courses/${courseId}/discussions/create`}>
            <Button>Start a Discussion</Button>
          </Link>
        </div>
      )}
    </div>
  )
}

function DiscussionsPageSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Skeleton className="h-10 w-10" />
        <Skeleton className="h-10 w-64" />
      </div>

      <div className="flex justify-between">
        <Skeleton className="h-10 w-full max-w-md" />
        <Skeleton className="h-10 w-40" />
      </div>

      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <Skeleton className="h-6 w-48" />
                <Skeleton className="h-4 w-24" />
              </div>
              <div className="flex items-center gap-2">
                <Skeleton className="h-6 w-6 rounded-full" />
                <Skeleton className="h-4 w-32" />
              </div>
            </CardHeader>
            <CardContent>
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4" />
            </CardContent>
            <CardFooter>
              <Skeleton className="h-4 w-24" />
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

