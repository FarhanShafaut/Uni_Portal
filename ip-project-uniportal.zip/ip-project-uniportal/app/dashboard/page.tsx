"use client"
import { useAuth } from "@/hooks/use-auth"
import { Loader2 } from "lucide-react"
import { TeacherDashboard } from "@/components/teacher-dashboard"
import { StudentDashboard } from "@/components/student-dashboard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function DashboardPage() {
  const { user, isLoading, isTeacher, isStudent } = useAuth()

  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Not Authenticated</CardTitle>
            <CardDescription>Please log in to access the dashboard</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Link href="/login">
              <Button>Log In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6">
      {isTeacher && <TeacherDashboard />}
      {isStudent && <StudentDashboard />}

      {!isTeacher && !isStudent && (
        <div className="rounded-lg border p-6 text-center">
          <h2 className="mb-2 text-xl font-semibold">Role not recognized</h2>
          <p className="text-muted-foreground">
            Your account doesn't have a valid role. Please contact an administrator.
          </p>
        </div>
      )}
    </div>
  )
}

