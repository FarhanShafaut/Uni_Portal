"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2 } from "lucide-react"
import { getUserCourses } from "@/lib/course-service"
import { createAnnouncement } from "@/lib/announcement-service"

export default function CreateAnnouncementPage() {
  const router = useRouter()
  const { isTeacher } = useAuth()
  const [courses, setCourses] = useState([])
  const [selectedCourse, setSelectedCourse] = useState("")
  const [content, setContent] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    async function fetchCourses() {
      try {
        const data = await getUserCourses()
        setCourses(data)
        if (data.length > 0) {
          setSelectedCourse(data[0]._id)
        }
      } catch (error) {
        console.error("Error fetching courses:", error)
        setError("Failed to load courses. Please try again.")
      } finally {
        setIsLoading(false)
      }
    }

    if (isTeacher) {
      fetchCourses()
    } else {
      router.push("/dashboard")
    }
  }, [isTeacher, router])

  async function handleSubmit(e) {
    e.preventDefault()

    if (!selectedCourse) {
      setError("Please select a course")
      return
    }

    if (!content.trim()) {
      setError("Please enter announcement content")
      return
    }

    setIsSubmitting(true)
    setError("")

    try {
      const result = await createAnnouncement(selectedCourse, content)

      if (result.success) {
        router.push("/dashboard/announcements")
      } else {
        setError(result.message || "Failed to create announcement")
      }
    } catch (error) {
      console.error("Error creating announcement:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Create Announcement</h1>

      <Card>
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>New Announcement</CardTitle>
            <CardDescription>Create an announcement for your students</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="course">Course</Label>
              <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                <SelectTrigger id="course">
                  <SelectValue placeholder="Select a course" />
                </SelectTrigger>
                <SelectContent>
                  {courses.map((course) => (
                    <SelectItem key={course._id} value={course._id}>
                      {course.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Announcement</Label>
              <Textarea
                id="content"
                placeholder="Enter your announcement here..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={6}
              />
            </div>

            {error && <div className="bg-destructive/10 text-destructive text-sm p-2 rounded">{error}</div>}
          </CardContent>
          <CardFooter className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                "Create Announcement"
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

