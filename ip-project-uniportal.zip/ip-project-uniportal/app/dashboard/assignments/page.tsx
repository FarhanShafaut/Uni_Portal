import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

// Sample assignment data
const assignments = [
  {
    id: "1",
    title: "Computing Concepts",
    course: "Introduction to Computer Science",
    dueDate: "October 15, 2023",
    status: "pending",
  },
  {
    id: "2",
    title: "Algorithm Design",
    course: "Introduction to Computer Science",
    dueDate: "October 29, 2023",
    status: "pending",
  },
  {
    id: "3",
    title: "Calculus Problem Set",
    course: "Advanced Mathematics",
    dueDate: "October 10, 2023",
    status: "submitted",
  },
]

export default function AssignmentsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Assignments</h1>

      <div className="space-y-4">
        {assignments.map((assignment) => (
          <Card key={assignment.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>{assignment.title}</CardTitle>
                  <CardDescription>Course: {assignment.course}</CardDescription>
                </div>
                <Badge variant={assignment.status === "submitted" ? "secondary" : "default"}>
                  {assignment.status === "submitted" ? "Submitted" : "Pending"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm">Due: {assignment.dueDate}</p>
            </CardContent>
            <CardFooter>
              <Link href={`/dashboard/assignments/${assignment.id}`} className="w-full">
                <Button variant="outline" className="w-full">
                  {assignment.status === "submitted" ? "View Submission" : "Submit Assignment"}
                </Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

