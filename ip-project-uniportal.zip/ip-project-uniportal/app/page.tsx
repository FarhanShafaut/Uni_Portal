import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import {
  GraduationCap,
  BookOpen,
  MessageSquare,
  Users,
  Award,
  Calendar,
  Globe,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  ArrowRight,
  Star,
  CheckCircle,
} from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-primary text-primary-foreground py-4 px-6 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <GraduationCap className="h-6 w-6" />
          <h1 className="text-xl font-bold">UniPortal</h1>
        </div>
        <div className="flex gap-4">
          <Link href="/login">
            <Button variant="secondary">Login</Button>
          </Link>
          <Link href="/register">
            <Button variant="outline" className="bg-primary-foreground text-primary hover:bg-primary-foreground/90">
              Register
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section with Animation */}
        <section className="relative py-24 px-6 bg-gradient-to-b from-primary/10 to-background overflow-hidden">
          <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 z-10">
              <div className="space-y-4 animate-fade-in">
                <h1 className="text-4xl md:text-6xl font-bold">
                  Welcome to <span className="text-primary">UniPortal</span>
                </h1>
                <p className="text-xl md:text-2xl text-muted-foreground">
                  A modern learning platform for students and teachers
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up">
                <Link href="/register?role=student">
                  <Button size="lg" className="w-full sm:w-auto">
                    Join as Student
                  </Button>
                </Link>
                <Link href="/register?role=teacher">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto">
                    Join as Teacher
                  </Button>
                </Link>
              </div>
            </div>
            <div className="relative animate-float">
              <Image
                src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=1000"
                alt="Students learning"
                width={600}
                height={400}
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-background p-4 rounded-lg shadow-lg animate-bounce-slow">
                <div className="flex items-center gap-2">
                  <Award className="h-8 w-8 text-primary" />
                  <div>
                    <p className="font-bold">Join Today</p>
                    <p className="text-sm text-muted-foreground">Start your learning journey</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Animated background elements */}
          <div className="absolute top-20 left-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl animate-blob"></div>
          <div className="absolute bottom-10 right-10 w-80 h-80 bg-secondary/10 rounded-full blur-3xl animate-blob animation-delay-2000"></div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-6 bg-muted/30">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold animate-fade-in">Powerful Features for Modern Education</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in animation-delay-300">
                Everything you need to create an engaging learning experience for students and teachers
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <FeatureCard
                icon={<BookOpen className="h-10 w-10 text-primary" />}
                title="Course Management"
                description="Create, join and manage courses with ease. Organize content, track progress, and deliver a seamless learning experience."
                delay="0"
              />
              <FeatureCard
                icon={<Calendar className="h-10 w-10 text-primary" />}
                title="Assignments & Grading"
                description="Create assignments, set deadlines, submit work, and provide feedback all in one place."
                delay="300"
              />
              <FeatureCard
                icon={<MessageSquare className="h-10 w-10 text-primary" />}
                title="Discussion Forums"
                description="Foster collaboration through course discussions. Ask questions, share insights, and build a community."
                delay="600"
              />
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-20 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">How UniPortal Works</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in animation-delay-300">
                Get started with UniPortal in just a few simple steps
              </p>
            </div>

            <div className="relative">
              {/* Connection line */}
              <div className="absolute top-1/2 left-0 w-full h-0.5 bg-primary/20 -translate-y-1/2 hidden md:block"></div>

              <div className="grid md:grid-cols-4 gap-8">
                <StepCard
                  number="1"
                  title="Create an Account"
                  description="Sign up as a student or teacher in just a few clicks"
                  delay="0"
                />
                <StepCard
                  number="2"
                  title="Join or Create Courses"
                  description="Browse available courses or create your own as a teacher"
                  delay="300"
                />
                <StepCard
                  number="3"
                  title="Access Materials"
                  description="Get instant access to course materials, assignments, and resources"
                  delay="600"
                />
                <StepCard
                  number="4"
                  title="Track Progress"
                  description="Monitor your learning journey with detailed analytics and feedback"
                  delay="900"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Course Categories Section */}
        <section className="py-20 px-6 bg-gradient-to-r from-primary/5 to-secondary/5">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Explore Course Categories</h2>
              <p className="text-xl text-muted-foreground animate-fade-in animation-delay-300">
                Discover a wide range of subjects and disciplines
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              <CategoryCard
                title="Computer Science"
                count="42 Courses"
                image="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=300"
              />
              <CategoryCard
                title="Business"
                count="38 Courses"
                image="https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=300"
              />
              <CategoryCard
                title="Mathematics"
                count="29 Courses"
                image="https://images.unsplash.com/photo-1635070041078-e363dbe005cb?q=80&w=300"
              />
              <CategoryCard
                title="Arts & Humanities"
                count="35 Courses"
                image="https://images.unsplash.com/photo-1452860606245-08befc0ff44b?q=80&w=300"
              />
              <CategoryCard
                title="Science"
                count="47 Courses"
                image="https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=80&w=300"
              />
              <CategoryCard
                title="Engineering"
                count="31 Courses"
                image="https://images.unsplash.com/photo-1581094794329-c8112a89af12?q=80&w=300"
              />
              <CategoryCard
                title="Languages"
                count="24 Courses"
                image="https://images.unsplash.com/photo-1546410531-bb4caa6b424d?q=80&w=300"
              />
              <CategoryCard
                title="Health & Medicine"
                count="33 Courses"
                image="https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=300"
              />
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-20 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">What Our Users Say</h2>
              <p className="text-xl text-muted-foreground animate-fade-in animation-delay-300">
                Hear from students and teachers who use UniPortal
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <TestimonialCard
                quote="UniPortal has transformed how I manage my courses. The interface is intuitive and my students love it!"
                name="Dr. Sarah Johnson"
                role="Professor of Computer Science"
                image="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200"
                rating={5}
              />
              <TestimonialCard
                quote="As a student, I appreciate how easy it is to access course materials, submit assignments, and communicate with professors."
                name="Michael Chen"
                role="Engineering Student"
                image="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=200"
                rating={5}
              />
              <TestimonialCard
                quote="The discussion forums have created a collaborative environment that extends beyond the classroom."
                name="Emily Rodriguez"
                role="Biology Major"
                image="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200"
                rating={4}
              />
            </div>
          </div>
        </section>

        {/* Faculty Spotlight Section */}
        <section className="py-20 px-6 bg-muted/30">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Meet Our Faculty</h2>
              <p className="text-xl text-muted-foreground animate-fade-in animation-delay-300">
                Learn from experienced educators and industry experts
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-8">
              <FacultyCard
                name="Prof. David Wilson"
                department="Computer Science"
                image="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200"
              />
              <FacultyCard
                name="Dr. Maria Garcia"
                department="Business Administration"
                image="https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=200"
              />
              <FacultyCard
                name="Prof. James Lee"
                department="Engineering"
                image="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200"
              />
              <FacultyCard
                name="Dr. Aisha Patel"
                department="Medicine"
                image="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200"
              />
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 px-6 bg-primary text-primary-foreground">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">UniPortal by the Numbers</h2>
              <p className="text-xl opacity-90 animate-fade-in animation-delay-300">
                Join our growing community of learners and educators
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <StatCard number="10,000+" label="Students" icon={<Users className="h-10 w-10" />} />
              <StatCard number="500+" label="Teachers" icon={<Award className="h-10 w-10" />} />
              <StatCard number="1,200+" label="Courses" icon={<BookOpen className="h-10 w-10" />} />
              <StatCard number="98%" label="Satisfaction" icon={<Star className="h-10 w-10" />} />
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-in">Why Choose UniPortal</h2>
              <p className="text-xl text-muted-foreground animate-fade-in animation-delay-300">
                Benefits that make us the preferred choice for education
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div className="relative">
                <Image
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=600"
                  alt="Students collaborating"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl animate-float"
                />
                <div className="absolute -bottom-6 -left-6 bg-primary text-primary-foreground p-4 rounded-lg shadow-lg">
                  <p className="font-bold">24/7 Learning Access</p>
                </div>
              </div>

              <div className="space-y-6 flex flex-col justify-center">
                <BenefitItem
                  title="Flexible Learning"
                  description="Access your courses anytime, anywhere, on any device"
                />
                <BenefitItem
                  title="Interactive Content"
                  description="Engage with multimedia resources, quizzes, and activities"
                />
                <BenefitItem
                  title="Real-time Feedback"
                  description="Get immediate responses and grades on your assignments"
                />
                <BenefitItem
                  title="Collaborative Environment"
                  description="Connect with peers and instructors through discussion forums"
                />
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 animate-fade-in">
              Ready to Transform Your Learning Experience?
            </h2>
            <p className="text-xl mb-8 opacity-90 animate-fade-in animation-delay-300">
              Join thousands of students and teachers already using UniPortal
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up animation-delay-600">
              <Link href="/register">
                <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                  Get Started Today
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/login">
                <Button size="lg" variant="outline" className="border-primary-foreground w-full sm:w-auto">
                  Log In
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      {/* Enhanced Footer */}
      <footer className="bg-gray-900 text-white py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <GraduationCap className="h-8 w-8 text-primary" />
                <h2 className="text-2xl font-bold">UniPortal</h2>
              </div>
              <p className="text-gray-400">
                A modern learning platform designed to transform education and make learning accessible to everyone.
              </p>
              <div className="flex space-x-4 pt-2">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Facebook className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Twitter className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Instagram className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Linkedin className="h-5 w-5" />
                </a>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Courses
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Faculty
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Student Resources
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Teacher Resources
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    API Documentation
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <MapPin className="h-5 w-5 text-gray-400 mr-2 mt-0.5" />
                  <span className="text-gray-400">123 Education Ave, Learning City, LC 12345</span>
                </li>
                <li className="flex items-center">
                  <Phone className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-gray-400">(123) 456-7890</span>
                </li>
                <li className="flex items-center">
                  <Mail className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-gray-400">info@uniportal.edu</span>
                </li>
                <li className="flex items-center">
                  <Globe className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-gray-400">www.uniportal.edu</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>© {new Date().getFullYear()} UniPortal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon, title, description, delay }) {
  return (
    <div
      className="bg-card rounded-lg p-6 shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex justify-center mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2 text-center">{title}</h3>
      <p className="text-muted-foreground text-center">{description}</p>
    </div>
  )
}

function StepCard({ number, title, description, delay }) {
  return (
    <div
      className="bg-card rounded-lg p-6 shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in-up relative z-10"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex justify-center mb-4">
        <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold">
          {number}
        </div>
      </div>
      <h3 className="text-xl font-semibold mb-2 text-center">{title}</h3>
      <p className="text-muted-foreground text-center">{description}</p>
    </div>
  )
}

function CategoryCard({ title, count, image }) {
  return (
    <div className="group relative overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-all duration-300 aspect-square animate-fade-in">
      <Image
        src={image || "/placeholder.svg"}
        alt={title}
        fill
        className="object-cover transition-transform duration-500 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
      <div className="absolute bottom-0 left-0 p-4 w-full">
        <h3 className="text-white font-semibold text-lg">{title}</h3>
        <p className="text-white/80 text-sm">{count}</p>
      </div>
    </div>
  )
}

function TestimonialCard({ quote, name, role, image, rating }) {
  return (
    <div className="bg-card rounded-lg p-6 shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in">
      <div className="mb-4">
        <svg className="h-8 w-8 text-primary/40" fill="currentColor" viewBox="0 0 32 32">
          <path d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z" />
        </svg>
      </div>
      <div className="flex mb-4">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`h-4 w-4 ${i < rating ? "text-yellow-400" : "text-gray-300"}`}
            fill={i < rating ? "currentColor" : "none"}
          />
        ))}
      </div>
      <p className="mb-4 italic">{quote}</p>
      <div className="flex items-center">
        <Image src={image || "/placeholder.svg"} alt={name} width={48} height={48} className="rounded-full mr-4" />
        <div>
          <p className="font-semibold">{name}</p>
          <p className="text-sm text-muted-foreground">{role}</p>
        </div>
      </div>
    </div>
  )
}

function FacultyCard({ name, department, image }) {
  return (
    <div className="group bg-card rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in">
      <div className="aspect-square relative overflow-hidden">
        <Image
          src={image || "/placeholder.svg"}
          alt={name}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      <div className="p-4 text-center">
        <h3 className="font-semibold text-lg">{name}</h3>
        <p className="text-muted-foreground">{department}</p>
      </div>
    </div>
  )
}

function StatCard({ number, label, icon }) {
  return (
    <div className="text-center animate-fade-in">
      <div className="flex justify-center mb-4">{icon}</div>
      <p className="text-3xl md:text-4xl font-bold mb-2">{number}</p>
      <p className="opacity-90">{label}</p>
    </div>
  )
}

function BenefitItem({ title, description }) {
  return (
    <div className="flex items-start animate-fade-in">
      <div className="mr-4 mt-1">
        <CheckCircle className="h-6 w-6 text-primary" />
      </div>
      <div>
        <h3 className="text-xl font-semibold mb-1">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </div>
    </div>
  )
}

