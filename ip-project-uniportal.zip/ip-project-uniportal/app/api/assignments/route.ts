import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")
    const submissionsCollection = db.collection("submissions")

    // Get courses where user is teacher or student
    let courseIds = []

    if (decoded.role === "teacher") {
      const teacherCourses = await coursesCollection
        .find({
          teacher: new ObjectId(decoded.id),
        })
        .toArray()

      courseIds = teacherCourses.map((course) => course._id)
    } else {
      const studentCourses = await coursesCollection
        .find({
          students: new ObjectId(decoded.id),
        })
        .toArray()

      courseIds = studentCourses.map((course) => course._id)
    }

    // Get assignments for those courses
    const assignments = await assignmentsCollection.find({ course: { $in: courseIds } }).toArray()

    // For students, get their submissions
    const populatedAssignments = await Promise.all(
      assignments.map(async (assignment) => {
        const course = await coursesCollection.findOne({ _id: assignment.course })

        let submission = null
        if (decoded.role === "student") {
          submission = await submissionsCollection.findOne({
            assignment: assignment._id,
            student: new ObjectId(decoded.id),
          })
        }

        return {
          ...assignment,
          course: {
            _id: course._id,
            title: course.title,
          },
          submission,
        }
      }),
    )

    return NextResponse.json({
      assignments: populatedAssignments,
    })
  } catch (error) {
    console.error("Get all assignments error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

