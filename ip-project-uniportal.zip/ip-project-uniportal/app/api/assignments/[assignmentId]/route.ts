import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request, { params }: { params: { assignmentId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")
    const submissionsCollection = db.collection("submissions")
    const usersCollection = db.collection("users")

    // Get assignment
    const assignment = await assignmentsCollection.findOne({
      _id: new ObjectId(params.assignmentId),
    })

    if (!assignment) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: assignment.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is enrolled in the course or is the teacher
    const isTeacher = course.teacher.toString() === decoded.id
    const isStudent = course.students && course.students.some((studentId) => studentId.toString() === decoded.id)

    if (!isTeacher && !isStudent) {
      return NextResponse.json({ message: "You are not enrolled in this course" }, { status: 403 })
    }

    // Get submission if student
    let submission = null
    if (decoded.role === "student") {
      submission = await submissionsCollection.findOne({
        assignment: new ObjectId(params.assignmentId),
        student: new ObjectId(decoded.id),
      })
    }

    // Get teacher info
    const teacher = await usersCollection.findOne({
      _id: course.teacher,
    })

    // Prepare response
    const assignmentWithDetails = {
      ...assignment,
      course: {
        _id: course._id,
        title: course.title,
        teacher: {
          _id: teacher._id,
          name: teacher.name,
        },
      },
      submission,
    }

    return NextResponse.json({
      assignment: assignmentWithDetails,
    })
  } catch (error) {
    console.error("Get assignment error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

export async function PUT(request: Request, { params }: { params: { assignmentId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    const { title, description, dueDate } = await request.json()

    // Validate input
    if (!title || !description || !dueDate) {
      return NextResponse.json({ message: "Title, description, and due date are required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")

    // Get assignment
    const assignment = await assignmentsCollection.findOne({
      _id: new ObjectId(params.assignmentId),
    })

    if (!assignment) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: assignment.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is the teacher of the course
    if (course.teacher.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the teacher can update this assignment" }, { status: 403 })
    }

    // Update assignment
    const result = await assignmentsCollection.updateOne(
      { _id: new ObjectId(params.assignmentId) },
      { $set: { title, description, dueDate: new Date(dueDate), updatedAt: new Date() } },
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    // Get updated assignment
    const updatedAssignment = await assignmentsCollection.findOne({
      _id: new ObjectId(params.assignmentId),
    })

    return NextResponse.json({
      message: "Assignment updated successfully",
      assignment: updatedAssignment,
    })
  } catch (error) {
    console.error("Update assignment error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

export async function DELETE(request: Request, { params }: { params: { assignmentId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const assignmentsCollection = db.collection("assignments")
    const submissionsCollection = db.collection("submissions")
    const coursesCollection = db.collection("courses")

    // Get assignment
    const assignment = await assignmentsCollection.findOne({
      _id: new ObjectId(params.assignmentId),
    })

    if (!assignment) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: assignment.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is the teacher of the course
    if (course.teacher.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the teacher can delete this assignment" }, { status: 403 })
    }

    // Delete all submissions for this assignment
    await submissionsCollection.deleteMany({
      assignment: new ObjectId(params.assignmentId),
    })

    // Delete assignment
    const result = await assignmentsCollection.deleteOne({
      _id: new ObjectId(params.assignmentId),
    })

    if (result.deletedCount === 0) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    return NextResponse.json({
      message: "Assignment deleted successfully",
    })
  } catch (error) {
    console.error("Delete assignment error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

