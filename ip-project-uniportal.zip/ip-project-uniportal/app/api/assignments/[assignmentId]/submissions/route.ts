import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request, { params }: { params: { assignmentId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    // Only teachers can view all submissions
    if (decoded.role !== "teacher") {
      return NextResponse.json({ message: "Only teachers can view all submissions" }, { status: 403 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const submissionsCollection = db.collection("submissions")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    // Get assignment
    const assignment = await assignmentsCollection.findOne({
      _id: new ObjectId(params.assignmentId),
    })

    if (!assignment) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: assignment.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is the teacher of the course
    if (course.teacher.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the teacher of this course can view submissions" }, { status: 403 })
    }

    // Get submissions for this assignment
    const submissions = await submissionsCollection
      .find({ assignment: new ObjectId(params.assignmentId) })
      .sort({ submittedAt: -1 })
      .toArray()

    // Populate student information
    const populatedSubmissions = await Promise.all(
      submissions.map(async (submission) => {
        const student = await usersCollection.findOne({ _id: submission.student })
        return {
          ...submission,
          student: {
            _id: student._id,
            name: student.name,
            email: student.email,
            profileImage: student.profileImage,
          },
        }
      }),
    )

    return NextResponse.json({
      submissions: populatedSubmissions,
    })
  } catch (error) {
    console.error("Get assignment submissions error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

