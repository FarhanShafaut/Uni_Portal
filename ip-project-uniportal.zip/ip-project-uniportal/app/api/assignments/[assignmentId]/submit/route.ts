import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function POST(request: Request, { params }: { params: { assignmentId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    // Only students can submit assignments
    if (decoded.role !== "student") {
      return NextResponse.json({ message: "Only students can submit assignments" }, { status: 403 })
    }

    const formData = await request.formData()
    const content = formData.get("content") as string

    // Validate input
    if (!content) {
      return NextResponse.json({ message: "Content is required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const submissionsCollection = db.collection("submissions")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")

    // Check if assignment exists
    const assignment = await assignmentsCollection.findOne({ _id: new ObjectId(params.assignmentId) })

    if (!assignment) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    // Check if user is enrolled in the course
    const course = await coursesCollection.findOne({ _id: assignment.course })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    const isEnrolled = course.students.some((studentId) => studentId.toString() === decoded.id)

    if (!isEnrolled) {
      return NextResponse.json({ message: "You are not enrolled in this course" }, { status: 403 })
    }

    // Check if assignment is past due
    if (new Date() > new Date(assignment.dueDate)) {
      return NextResponse.json({ message: "Assignment is past due" }, { status: 400 })
    }

    // Check if student has already submitted
    const existingSubmission = await submissionsCollection.findOne({
      assignment: new ObjectId(params.assignmentId),
      student: new ObjectId(decoded.id),
    })

    if (existingSubmission) {
      return NextResponse.json({ message: "You have already submitted this assignment" }, { status: 400 })
    }

    // Create submission
    const newSubmission = {
      content,
      assignment: new ObjectId(params.assignmentId),
      student: new ObjectId(decoded.id),
      submittedAt: new Date(),
      grade: null,
      feedback: null,
    }

    const result = await submissionsCollection.insertOne(newSubmission)

    return NextResponse.json({
      message: "Assignment submitted successfully",
      submission: { ...newSubmission, _id: result.insertedId },
    })
  } catch (error) {
    console.error("Submit assignment error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

