import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function POST(request: Request, { params }: { params: { discussionId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    const { content } = await request.json()

    // Validate input
    if (!content) {
      return NextResponse.json({ message: "Content is required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const discussionsCollection = db.collection("discussions")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    // Get discussion
    const discussion = await discussionsCollection.findOne({
      _id: new ObjectId(params.discussionId),
    })

    if (!discussion) {
      return NextResponse.json({ message: "Discussion not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: discussion.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is enrolled in the course or is the teacher
    const isTeacher = course.teacher.toString() === decoded.id
    const isStudent = course.students && course.students.some((studentId) => studentId.toString() === decoded.id)

    if (!isTeacher && !isStudent) {
      return NextResponse.json({ message: "You are not enrolled in this course" }, { status: 403 })
    }

    // Create comment
    const newComment = {
      _id: new ObjectId(),
      content,
      createdBy: new ObjectId(decoded.id),
      createdAt: new Date(),
    }

    // Add comment to discussion
    await discussionsCollection.updateOne(
      { _id: new ObjectId(params.discussionId) },
      { $push: { comments: newComment } },
    )

    // Get user info for response
    const user = await usersCollection.findOne({
      _id: new ObjectId(decoded.id),
    })

    // Prepare response
    const commentWithUser = {
      ...newComment,
      createdBy: {
        _id: user._id,
        name: user.name,
        role: user.role,
        profileImage: user.profileImage,
      },
    }

    return NextResponse.json({
      message: "Comment added successfully",
      comment: commentWithUser,
    })
  } catch (error) {
    console.error("Add comment error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

