import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function DELETE(request: Request, { params }: { params: { discussionId: string; commentId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const discussionsCollection = db.collection("discussions")

    // Get discussion
    const discussion = await discussionsCollection.findOne({
      _id: new ObjectId(params.discussionId),
    })

    if (!discussion) {
      return NextResponse.json({ message: "Discussion not found" }, { status: 404 })
    }

    // Find the comment
    const comment = discussion.comments.find((c) => c._id.toString() === params.commentId)

    if (!comment) {
      return NextResponse.json({ message: "Comment not found" }, { status: 404 })
    }

    // Check if user is the creator of the comment or a teacher
    if (comment.createdBy.toString() !== decoded.id && decoded.role !== "teacher") {
      return NextResponse.json({ message: "You can only delete your own comments" }, { status: 403 })
    }

    // Remove the comment
    await discussionsCollection.updateOne(
      { _id: new ObjectId(params.discussionId) },
      { $pull: { comments: { _id: new ObjectId(params.commentId) } } },
    )

    return NextResponse.json({
      message: "Comment deleted successfully",
    })
  } catch (error) {
    console.error("Delete comment error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

