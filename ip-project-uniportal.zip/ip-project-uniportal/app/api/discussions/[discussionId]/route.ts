import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request, { params }: { params: { discussionId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const discussionsCollection = db.collection("discussions")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    // Get discussion
    const discussion = await discussionsCollection.findOne({
      _id: new ObjectId(params.discussionId),
    })

    if (!discussion) {
      return NextResponse.json({ message: "Discussion not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: discussion.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is enrolled in the course or is the teacher
    const isTeacher = course.teacher.toString() === decoded.id
    const isStudent = course.students && course.students.some((studentId) => studentId.toString() === decoded.id)

    if (!isTeacher && !isStudent) {
      return NextResponse.json({ message: "You are not enrolled in this course" }, { status: 403 })
    }

    // Get creator info
    const creator = await usersCollection.findOne({
      _id: discussion.createdBy,
    })

    // Get comment creators info
    const populatedComments = await Promise.all(
      (discussion.comments || []).map(async (comment) => {
        const commentCreator = await usersCollection.findOne({
          _id: comment.createdBy,
        })
        return {
          ...comment,
          createdBy: {
            _id: commentCreator._id,
            name: commentCreator.name,
            role: commentCreator.role,
            profileImage: commentCreator.profileImage,
          },
        }
      }),
    )

    // Prepare response
    const discussionWithDetails = {
      ...discussion,
      createdBy: {
        _id: creator._id,
        name: creator.name,
        role: creator.role,
        profileImage: creator.profileImage,
      },
      comments: populatedComments,
      course: {
        _id: course._id,
        title: course.title,
      },
    }

    return NextResponse.json({
      discussion: discussionWithDetails,
    })
  } catch (error) {
    console.error("Get discussion error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

export async function PUT(request: Request, { params }: { params: { discussionId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    const { title, content } = await request.json()

    // Validate input
    if (!title || !content) {
      return NextResponse.json({ message: "Title and content are required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const discussionsCollection = db.collection("discussions")

    // Get discussion
    const discussion = await discussionsCollection.findOne({
      _id: new ObjectId(params.discussionId),
    })

    if (!discussion) {
      return NextResponse.json({ message: "Discussion not found" }, { status: 404 })
    }

    // Check if user is the creator of the discussion
    if (discussion.createdBy.toString() !== decoded.id) {
      return NextResponse.json({ message: "You can only edit your own discussions" }, { status: 403 })
    }

    // Update discussion
    await discussionsCollection.updateOne(
      { _id: new ObjectId(params.discussionId) },
      { $set: { title, content, updatedAt: new Date() } },
    )

    // Get updated discussion
    const updatedDiscussion = await discussionsCollection.findOne({
      _id: new ObjectId(params.discussionId),
    })

    return NextResponse.json({
      message: "Discussion updated successfully",
      discussion: updatedDiscussion,
    })
  } catch (error) {
    console.error("Update discussion error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

export async function DELETE(request: Request, { params }: { params: { discussionId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const discussionsCollection = db.collection("discussions")

    // Get discussion
    const discussion = await discussionsCollection.findOne({
      _id: new ObjectId(params.discussionId),
    })

    if (!discussion) {
      return NextResponse.json({ message: "Discussion not found" }, { status: 404 })
    }

    // Check if user is the creator of the discussion or a teacher
    const isCreator = discussion.createdBy.toString() === decoded.id
    const isTeacher = decoded.role === "teacher"

    if (!isCreator && !isTeacher) {
      return NextResponse.json({ message: "You can only delete your own discussions" }, { status: 403 })
    }

    // Delete discussion
    await discussionsCollection.deleteOne({
      _id: new ObjectId(params.discussionId),
    })

    return NextResponse.json({
      message: "Discussion deleted successfully",
    })
  } catch (error) {
    console.error("Delete discussion error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

