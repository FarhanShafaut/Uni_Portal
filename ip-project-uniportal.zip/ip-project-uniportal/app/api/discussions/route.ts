import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const discussionsCollection = db.collection("discussions")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    // Get courses where user is teacher or student
    let courseIds = []

    if (decoded.role === "teacher") {
      const teacherCourses = await coursesCollection
        .find({
          teacher: new ObjectId(decoded.id),
        })
        .toArray()

      courseIds = teacherCourses.map((course) => course._id)
    } else {
      const studentCourses = await coursesCollection
        .find({
          students: new ObjectId(decoded.id),
        })
        .toArray()

      courseIds = studentCourses.map((course) => course._id)
    }

    // Get discussions for those courses
    const discussions = await discussionsCollection
      .find({ course: { $in: courseIds } })
      .sort({ createdAt: -1 })
      .toArray()

    // Populate creator information and course information
    const populatedDiscussions = await Promise.all(
      discussions.map(async (discussion) => {
        const creator = await usersCollection.findOne({ _id: discussion.createdBy })
        const course = await coursesCollection.findOne({ _id: discussion.course })

        return {
          ...discussion,
          createdBy: {
            _id: creator._id,
            name: creator.name,
            role: creator.role,
            profileImage: creator.profileImage,
          },
          course: {
            _id: course._id,
            title: course.title,
          },
        }
      }),
    )

    return NextResponse.json({
      discussions: populatedDiscussions,
    })
  } catch (error) {
    console.error("Get all discussions error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

