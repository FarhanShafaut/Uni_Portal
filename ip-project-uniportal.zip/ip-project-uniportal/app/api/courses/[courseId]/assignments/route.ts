import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

// Get course assignments
export async function GET(request: Request, { params }: { params: { courseId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")

    // Check if course exists
    const course = await coursesCollection.findOne({ _id: new ObjectId(params.courseId) })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is enrolled in the course or is the teacher
    const isTeacher = course.teacher.toString() === decoded.id
    const isStudent = course.students.some((studentId) => studentId.toString() === decoded.id)

    if (!isTeacher && !isStudent) {
      return NextResponse.json({ message: "You are not enrolled in this course" }, { status: 403 })
    }

    // Get assignments for the course
    const assignments = await assignmentsCollection
      .find({ course: new ObjectId(params.courseId) })
      .sort({ dueDate: 1 })
      .toArray()

    return NextResponse.json({
      assignments,
    })
  } catch (error) {
    console.error("Get course assignments error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

// Create a new assignment
export async function POST(request: Request, { params }: { params: { courseId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    const { title, description, dueDate } = await request.json()

    // Validate input
    if (!title || !description || !dueDate) {
      return NextResponse.json({ message: "Title, description, and due date are required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")

    // Check if course exists
    const course = await coursesCollection.findOne({ _id: new ObjectId(params.courseId) })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Only the teacher can create assignments
    if (course.teacher.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the teacher can create assignments" }, { status: 403 })
    }

    // Create assignment
    const newAssignment = {
      title,
      description,
      dueDate: new Date(dueDate),
      course: new ObjectId(params.courseId),
      createdBy: new ObjectId(decoded.id),
      createdAt: new Date(),
    }

    const result = await assignmentsCollection.insertOne(newAssignment)

    return NextResponse.json({
      message: "Assignment created successfully",
      assignment: { ...newAssignment, _id: result.insertedId },
    })
  } catch (error) {
    console.error("Create assignment error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

