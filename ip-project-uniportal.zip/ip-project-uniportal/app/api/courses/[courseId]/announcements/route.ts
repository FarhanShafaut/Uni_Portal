import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

// Get course announcements
export async function GET(request: Request, { params }: { params: { courseId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const announcementsCollection = db.collection("announcements")
    const coursesCollection = db.collection("courses")

    // Check if course exists
    const course = await coursesCollection.findOne({ _id: new ObjectId(params.courseId) })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is enrolled in the course or is the teacher
    const isTeacher = course.teacher.toString() === decoded.id
    const isStudent = course.students.some((studentId) => studentId.toString() === decoded.id)

    if (!isTeacher && !isStudent) {
      return NextResponse.json({ message: "You are not enrolled in this course" }, { status: 403 })
    }

    // Get announcements for the course
    const announcements = await announcementsCollection
      .find({ course: new ObjectId(params.courseId) })
      .sort({ createdAt: -1 })
      .toArray()

    return NextResponse.json({
      announcements,
    })
  } catch (error) {
    console.error("Get course announcements error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

// Create a new announcement
export async function POST(request: Request, { params }: { params: { courseId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    const { content } = await request.json()

    // Validate input
    if (!content) {
      return NextResponse.json({ message: "Content is required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const announcementsCollection = db.collection("announcements")
    const coursesCollection = db.collection("courses")

    // Check if course exists
    const course = await coursesCollection.findOne({ _id: new ObjectId(params.courseId) })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Only the teacher can create announcements
    if (course.teacher.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the teacher can create announcements" }, { status: 403 })
    }

    // Create announcement
    const newAnnouncement = {
      content,
      course: new ObjectId(params.courseId),
      createdBy: new ObjectId(decoded.id),
      createdAt: new Date(),
    }

    const result = await announcementsCollection.insertOne(newAnnouncement)

    return NextResponse.json({
      message: "Announcement created successfully",
      announcement: { ...newAnnouncement, _id: result.insertedId },
    })
  } catch (error) {
    console.error("Create announcement error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

