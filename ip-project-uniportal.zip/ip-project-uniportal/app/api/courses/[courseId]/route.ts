import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request, { params }: { params: { courseId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    // Get course by ID
    const course = await coursesCollection.findOne({ _id: new ObjectId(params.courseId) })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Populate teacher information
    const teacher = await usersCollection.findOne({ _id: course.teacher })

    // Populate student information
    const studentIds = course.students || []
    const students = await Promise.all(
      studentIds.map(async (studentId) => {
        const student = await usersCollection.findOne({ _id: studentId })
        return student
          ? {
              _id: student._id,
              name: student.name,
              email: student.email,
              profileImage: student.profileImage,
            }
          : null
      }),
    ).then((students) => students.filter(Boolean))

    const populatedCourse = {
      ...course,
      teacher: {
        _id: teacher._id,
        name: teacher.name,
        email: teacher.email,
        profileImage: teacher.profileImage,
      },
      students,
    }

    return NextResponse.json({
      course: populatedCourse,
    })
  } catch (error) {
    console.error("Get course error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

export async function PUT(request: Request, { params }: { params: { courseId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    const { title, description } = await request.json()

    // Validate input
    if (!title || !description) {
      return NextResponse.json({ message: "Title and description are required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const coursesCollection = db.collection("courses")

    // Get course
    const course = await coursesCollection.findOne({ _id: new ObjectId(params.courseId) })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is the teacher of the course
    if (course.teacher.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the teacher can update this course" }, { status: 403 })
    }

    // Update course
    const result = await coursesCollection.updateOne(
      { _id: new ObjectId(params.courseId) },
      { $set: { title, description, updatedAt: new Date() } },
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Get updated course
    const updatedCourse = await coursesCollection.findOne({ _id: new ObjectId(params.courseId) })

    return NextResponse.json({
      message: "Course updated successfully",
      course: updatedCourse,
    })
  } catch (error) {
    console.error("Update course error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

export async function DELETE(request: Request, { params }: { params: { courseId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const coursesCollection = db.collection("courses")
    const assignmentsCollection = db.collection("assignments")
    const announcementsCollection = db.collection("announcements")
    const discussionsCollection = db.collection("discussions")

    // Get course
    const course = await coursesCollection.findOne({ _id: new ObjectId(params.courseId) })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is the teacher of the course
    if (course.teacher.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the teacher can delete this course" }, { status: 403 })
    }

    // Delete all related data
    await Promise.all([
      assignmentsCollection.deleteMany({ course: new ObjectId(params.courseId) }),
      announcementsCollection.deleteMany({ course: new ObjectId(params.courseId) }),
      discussionsCollection.deleteMany({ course: new ObjectId(params.courseId) }),
    ])

    // Delete course
    const result = await coursesCollection.deleteOne({ _id: new ObjectId(params.courseId) })

    if (result.deletedCount === 0) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    return NextResponse.json({
      message: "Course deleted successfully",
    })
  } catch (error) {
    console.error("Delete course error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

