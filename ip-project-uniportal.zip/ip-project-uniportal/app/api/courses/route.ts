import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

// Get all courses
export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const coursesCollection = db.collection("courses")

    // Get all courses
    const courses = await coursesCollection.find().toArray()

    return NextResponse.json({
      courses,
    })
  } catch (error) {
    console.error("Get courses error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

// Create a new course
export async function POST(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    // Only teachers can create courses
    if (decoded.role !== "teacher") {
      return NextResponse.json({ message: "Only teachers can create courses" }, { status: 403 })
    }

    const { title, description } = await request.json()

    // Validate input
    if (!title || !description) {
      return NextResponse.json({ message: "Title and description are required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const coursesCollection = db.collection("courses")

    // Create course
    const newCourse = {
      title,
      description,
      teacher: new ObjectId(decoded.id),
      students: [],
      createdAt: new Date(),
    }

    const result = await coursesCollection.insertOne(newCourse)

    return NextResponse.json({
      message: "Course created successfully",
      course: { ...newCourse, _id: result.insertedId },
    })
  } catch (error) {
    console.error("Create course error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

