import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    let courses = []

    if (decoded.role === "teacher") {
      // Get courses where user is the teacher
      courses = await coursesCollection.find({ teacher: new ObjectId(decoded.id) }).toArray()
    } else {
      // Get courses where user is a student
      courses = await coursesCollection.find({ students: new ObjectId(decoded.id) }).toArray()
    }

    // Populate teacher information
    const populatedCourses = await Promise.all(
      courses.map(async (course) => {
        const teacher = await usersCollection.findOne({ _id: course.teacher })
        return {
          ...course,
          teacher: {
            _id: teacher._id,
            name: teacher.name,
            email: teacher.email,
          },
        }
      }),
    )

    return NextResponse.json({
      courses: populatedCourses,
    })
  } catch (error) {
    console.error("Get user courses error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

