import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request, { params }: { params: { announcementId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const announcementsCollection = db.collection("announcements")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    // Get announcement
    const announcement = await announcementsCollection.findOne({
      _id: new ObjectId(params.announcementId),
    })

    if (!announcement) {
      return NextResponse.json({ message: "Announcement not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: announcement.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is enrolled in the course or is the teacher
    const isTeacher = course.teacher.toString() === decoded.id
    const isStudent = course.students && course.students.some((studentId) => studentId.toString() === decoded.id)

    if (!isTeacher && !isStudent) {
      return NextResponse.json({ message: "You are not enrolled in this course" }, { status: 403 })
    }

    // Get creator info
    const creator = await usersCollection.findOne({
      _id: announcement.createdBy,
    })

    // Prepare response
    const announcementWithDetails = {
      ...announcement,
      createdBy: {
        _id: creator._id,
        name: creator.name,
        role: creator.role,
      },
      course: {
        _id: course._id,
        title: course.title,
      },
    }

    return NextResponse.json({
      announcement: announcementWithDetails,
    })
  } catch (error) {
    console.error("Get announcement error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

export async function PUT(request: Request, { params }: { params: { announcementId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    const { content } = await request.json()

    // Validate input
    if (!content) {
      return NextResponse.json({ message: "Content is required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const announcementsCollection = db.collection("announcements")

    // Get announcement
    const announcement = await announcementsCollection.findOne({
      _id: new ObjectId(params.announcementId),
    })

    if (!announcement) {
      return NextResponse.json({ message: "Announcement not found" }, { status: 404 })
    }

    // Check if user is the creator of the announcement
    if (announcement.createdBy.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the creator can update this announcement" }, { status: 403 })
    }

    // Update announcement
    const result = await announcementsCollection.updateOne(
      { _id: new ObjectId(params.announcementId) },
      { $set: { content, updatedAt: new Date() } },
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ message: "Announcement not found" }, { status: 404 })
    }

    // Get updated announcement
    const updatedAnnouncement = await announcementsCollection.findOne({
      _id: new ObjectId(params.announcementId),
    })

    return NextResponse.json({
      message: "Announcement updated successfully",
      announcement: updatedAnnouncement,
    })
  } catch (error) {
    console.error("Update announcement error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

export async function DELETE(request: Request, { params }: { params: { announcementId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const announcementsCollection = db.collection("announcements")

    // Get announcement
    const announcement = await announcementsCollection.findOne({
      _id: new ObjectId(params.announcementId),
    })

    if (!announcement) {
      return NextResponse.json({ message: "Announcement not found" }, { status: 404 })
    }

    // Check if user is the creator of the announcement
    if (announcement.createdBy.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the creator can delete this announcement" }, { status: 403 })
    }

    // Delete announcement
    const result = await announcementsCollection.deleteOne({
      _id: new ObjectId(params.announcementId),
    })

    if (result.deletedCount === 0) {
      return NextResponse.json({ message: "Announcement not found" }, { status: 404 })
    }

    return NextResponse.json({
      message: "Announcement deleted successfully",
    })
  } catch (error) {
    console.error("Delete announcement error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

