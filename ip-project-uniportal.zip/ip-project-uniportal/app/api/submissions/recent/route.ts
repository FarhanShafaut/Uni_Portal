import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    // Only teachers can view recent submissions
    if (decoded.role !== "teacher") {
      return NextResponse.json({ message: "Only teachers can view recent submissions" }, { status: 403 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const submissionsCollection = db.collection("submissions")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    // Get courses taught by the teacher
    const courses = await coursesCollection.find({ teacher: new ObjectId(decoded.id) }).toArray()
    const courseIds = courses.map((course) => course._id)

    // Get assignments for these courses
    const assignments = await assignmentsCollection.find({ course: { $in: courseIds } }).toArray()
    const assignmentIds = assignments.map((assignment) => assignment._id)

    // Get recent submissions for these assignments
    const submissions = await submissionsCollection
      .find({ assignment: { $in: assignmentIds } })
      .sort({ submittedAt: -1 })
      .limit(10)
      .toArray()

    // Populate submission data
    const populatedSubmissions = await Promise.all(
      submissions.map(async (submission) => {
        const assignment = await assignmentsCollection.findOne({ _id: submission.assignment })
        const course = await coursesCollection.findOne({ _id: assignment.course })
        const student = await usersCollection.findOne({ _id: submission.student })

        return {
          ...submission,
          assignment: {
            _id: assignment._id,
            title: assignment.title,
            course: {
              _id: course._id,
              title: course.title,
            },
          },
          student: {
            _id: student._id,
            name: student.name,
            email: student.email,
          },
        }
      }),
    )

    return NextResponse.json({
      submissions: populatedSubmissions,
    })
  } catch (error) {
    console.error("Get recent submissions error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

