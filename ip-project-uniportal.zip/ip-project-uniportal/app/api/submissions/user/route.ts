import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const submissionsCollection = db.collection("submissions")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")

    // Get submissions for the user
    const submissions = await submissionsCollection
      .find({ student: new ObjectId(decoded.id) })
      .sort({ submittedAt: -1 })
      .toArray()

    // Populate assignment and course information
    const populatedSubmissions = await Promise.all(
      submissions.map(async (submission) => {
        const assignment = await assignmentsCollection.findOne({ _id: submission.assignment })
        const course = await coursesCollection.findOne({ _id: assignment.course })

        return {
          ...submission,
          assignment: {
            _id: assignment._id,
            title: assignment.title,
            dueDate: assignment.dueDate,
            course: {
              _id: course._id,
              title: course.title,
            },
          },
        }
      }),
    )

    return NextResponse.json({
      submissions: populatedSubmissions,
    })
  } catch (error) {
    console.error("Get user submissions error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

