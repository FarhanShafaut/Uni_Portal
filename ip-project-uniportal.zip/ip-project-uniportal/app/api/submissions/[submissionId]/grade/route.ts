import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function POST(request: Request, { params }: { params: { submissionId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    // Only teachers can grade submissions
    if (decoded.role !== "teacher") {
      return NextResponse.json({ message: "Only teachers can grade submissions" }, { status: 403 })
    }

    const { grade, feedback } = await request.json()

    // Validate input
    if (grade === undefined || grade < 0 || grade > 100) {
      return NextResponse.json({ message: "Grade must be between 0 and 100" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const submissionsCollection = db.collection("submissions")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")

    // Get submission
    const submission = await submissionsCollection.findOne({
      _id: new ObjectId(params.submissionId),
    })

    if (!submission) {
      return NextResponse.json({ message: "Submission not found" }, { status: 404 })
    }

    // Get assignment
    const assignment = await assignmentsCollection.findOne({
      _id: submission.assignment,
    })

    if (!assignment) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: assignment.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is the teacher of the course
    if (course.teacher.toString() !== decoded.id) {
      return NextResponse.json({ message: "Only the teacher of this course can grade submissions" }, { status: 403 })
    }

    // Update submission
    const result = await submissionsCollection.updateOne(
      { _id: new ObjectId(params.submissionId) },
      { $set: { grade, feedback, gradedAt: new Date(), gradedBy: new ObjectId(decoded.id) } },
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ message: "Submission not found" }, { status: 404 })
    }

    // Get updated submission
    const updatedSubmission = await submissionsCollection.findOne({
      _id: new ObjectId(params.submissionId),
    })

    return NextResponse.json({
      message: "Submission graded successfully",
      submission: updatedSubmission,
    })
  } catch (error) {
    console.error("Grade submission error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

