import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request, { params }: { params: { submissionId: string } }) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const submissionsCollection = db.collection("submissions")
    const assignmentsCollection = db.collection("assignments")
    const coursesCollection = db.collection("courses")
    const usersCollection = db.collection("users")

    // Get submission
    const submission = await submissionsCollection.findOne({
      _id: new ObjectId(params.submissionId),
    })

    if (!submission) {
      return NextResponse.json({ message: "Submission not found" }, { status: 404 })
    }

    // Get assignment
    const assignment = await assignmentsCollection.findOne({
      _id: submission.assignment,
    })

    if (!assignment) {
      return NextResponse.json({ message: "Assignment not found" }, { status: 404 })
    }

    // Get course
    const course = await coursesCollection.findOne({
      _id: assignment.course,
    })

    if (!course) {
      return NextResponse.json({ message: "Course not found" }, { status: 404 })
    }

    // Check if user is the teacher of the course or the student who submitted
    const isTeacher = course.teacher.toString() === decoded.id
    const isStudent = submission.student.toString() === decoded.id

    if (!isTeacher && !isStudent) {
      return NextResponse.json({ message: "You are not authorized to view this submission" }, { status: 403 })
    }

    // Get student info
    const student = await usersCollection.findOne({
      _id: submission.student,
    })

    // Populate the submission with necessary information
    const populatedSubmission = {
      ...submission,
      student: {
        _id: student._id,
        name: student.name,
        email: student.email,
        profileImage: student.profileImage,
      },
      assignment: {
        _id: assignment._id,
        title: assignment.title,
        description: assignment.description,
        dueDate: assignment.dueDate,
        course: {
          _id: course._id,
          title: course.title,
        },
      },
    }

    return NextResponse.json({
      submission: populatedSubmission,
    })
  } catch (error) {
    console.error("Get submission error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

