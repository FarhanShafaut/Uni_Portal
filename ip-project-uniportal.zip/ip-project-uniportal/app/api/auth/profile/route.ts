import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"
import { writeFile } from "fs/promises"
import path from "path"
import { v4 as uuidv4 } from "uuid"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function PUT(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string }

    // Parse form data
    const formData = await request.formData()
    const name = formData.get("name") as string
    const profileImage = formData.get("profileImage") as File | null

    // Validate input
    if (!name) {
      return NextResponse.json({ message: "Name is required" }, { status: 400 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const usersCollection = db.collection("users")

    // Update object
    const updateObj: any = { name }

    // Handle profile image upload if provided
    if (profileImage) {
      const bytes = await profileImage.arrayBuffer()
      const buffer = Buffer.from(bytes)

      // Create a unique filename
      const filename = `${uuidv4()}-${profileImage.name}`
      const uploadDir = path.join(process.cwd(), "public/uploads")

      // Ensure the directory exists
      await writeFile(`${uploadDir}/${filename}`, buffer)

      // Update the profile image path in the database
      updateObj.profileImage = `/uploads/${filename}`
    }

    // Update user
    const result = await usersCollection.updateOne({ _id: new ObjectId(decoded.id) }, { $set: updateObj })

    if (result.matchedCount === 0) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    // Get updated user
    const updatedUser = await usersCollection.findOne({ _id: new ObjectId(decoded.id) })

    // Return user without password
    const { password, ...userWithoutPassword } = updatedUser

    return NextResponse.json({
      message: "Profile updated successfully",
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Update profile error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

