import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; email: string; role: string }

    await client.connect()
    const db = client.db("uniportal")
    const usersCollection = db.collection("users")

    // Find user by id
    const user = await usersCollection.findOne({ _id: new ObjectId(decoded.id) })

    if (!user) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    // Return user data (excluding password)
    const { password, ...userData } = user

    return NextResponse.json({
      user: {
        ...userData,
        _id: userData._id.toString(),
      },
    })
  } catch (error) {
    console.error("Get current user error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

