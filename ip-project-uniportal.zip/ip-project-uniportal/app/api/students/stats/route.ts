import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    // Only students can access student stats
    if (decoded.role !== "student") {
      return NextResponse.json({ message: "Access denied" }, { status: 403 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const coursesCollection = db.collection("courses")
    const assignmentsCollection = db.collection("assignments")
    const submissionsCollection = db.collection("submissions")

    // Get enrolled courses
    const enrolledCourses = await coursesCollection
      .find({
        students: new ObjectId(decoded.id),
      })
      .toArray()

    // Get course IDs
    const courseIds = enrolledCourses.map((course) => course._id)

    // Get assignments for enrolled courses
    const assignments = await assignmentsCollection
      .find({
        course: { $in: courseIds },
      })
      .toArray()

    // Get submissions by the student
    const submissions = await submissionsCollection
      .find({
        student: new ObjectId(decoded.id),
      })
      .toArray()

    // Calculate stats
    const enrolledCoursesCount = enrolledCourses.length
    const completedAssignmentsCount = submissions.length

    // Count pending assignments (due in the future and not submitted)
    const submittedAssignmentIds = submissions.map((sub) => sub.assignment.toString())
    const pendingAssignmentsCount = assignments.filter(
      (assignment) =>
        !submittedAssignmentIds.includes(assignment._id.toString()) && new Date(assignment.dueDate) > new Date(),
    ).length

    // Calculate average grade
    let averageGrade = 0
    const gradedSubmissions = submissions.filter((sub) => sub.grade !== null)

    if (gradedSubmissions.length > 0) {
      const totalGrade = gradedSubmissions.reduce((sum, sub) => sum + sub.grade, 0)
      averageGrade = Math.round(totalGrade / gradedSubmissions.length)
    }

    return NextResponse.json({
      stats: {
        enrolledCourses: enrolledCoursesCount,
        completedAssignments: completedAssignmentsCount,
        pendingAssignments: pendingAssignmentsCount,
        averageGrade,
      },
    })
  } catch (error) {
    console.error("Get student stats error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

