import { NextResponse } from "next/server"
import { MongoClient, ObjectId } from "mongodb"
import jwt from "jsonwebtoken"

const uri = process.env.MONGODB_URI
const client = new MongoClient(uri)

export async function GET(request: Request) {
  try {
    // Get token from header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, "your_jwt_secret") as { id: string; role: string }

    // Only teachers can access teacher stats
    if (decoded.role !== "teacher") {
      return NextResponse.json({ message: "Access denied" }, { status: 403 })
    }

    await client.connect()
    const db = client.db("uniportal")
    const coursesCollection = db.collection("courses")
    const assignmentsCollection = db.collection("assignments")
    const submissionsCollection = db.collection("submissions")

    // Get courses taught by the teacher
    const courses = await coursesCollection
      .find({
        teacher: new ObjectId(decoded.id),
      })
      .toArray()

    // Get course IDs
    const courseIds = courses.map((course) => course._id)

    // Get assignments for the courses
    const assignments = await assignmentsCollection
      .find({
        course: { $in: courseIds },
      })
      .toArray()

    // Get assignment IDs
    const assignmentIds = assignments.map((assignment) => assignment._id)

    // Get submissions for the assignments
    const submissions = await submissionsCollection
      .find({
        assignment: { $in: assignmentIds },
      })
      .toArray()

    // Calculate stats
    const totalCourses = courses.length

    // Count total students (unique students across all courses)
    const studentIds = new Set()
    courses.forEach((course) => {
      if (course.students && Array.isArray(course.students)) {
        course.students.forEach((studentId) => {
          studentIds.add(studentId.toString())
        })
      }
    })
    const totalStudents = studentIds.size

    // Count total assignments
    const totalAssignments = assignments.length

    // Count pending grading (submissions without grades)
    const pendingGrading = submissions.filter((sub) => sub.grade === null).length

    return NextResponse.json({
      stats: {
        totalStudents,
        totalCourses,
        totalAssignments,
        pendingGrading,
      },
    })
  } catch (error) {
    console.error("Get teacher stats error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  } finally {
    await client.close()
  }
}

