"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { getUserCourses } from "@/lib/course-service"
import { getStudentStats } from "@/lib/student-service"
import { getUpcomingAssignments } from "@/lib/assignment-service"
import { getAnnouncements } from "@/lib/announcement-service"
import { BookOpen, FileText, Calendar, Search } from "lucide-react"
import { format } from "date-fns"

export function StudentDashboard() {
  const [courses, setCourses] = useState([])
  const [stats, setStats] = useState({
    enrolledCourses: 0,
    completedAssignments: 0,
    pendingAssignments: 0,
    averageGrade: 0,
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        const [coursesData, statsData] = await Promise.all([getUserCourses(), getStudentStats()])

        setCourses(coursesData)
        setStats(statsData)
      } catch (error) {
        console.error("Error fetching student dashboard data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  if (isLoading) {
    return <DashboardSkeleton />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Student Dashboard</h1>
        <Link href="/dashboard/courses/browse">
          <Button>
            <Search className="mr-2 h-4 w-4" />
            Browse Courses
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Enrolled Courses"
          value={stats.enrolledCourses}
          icon={<BookOpen className="h-5 w-5" />}
          description="Courses you're taking"
        />
        <StatsCard
          title="Completed Assignments"
          value={stats.completedAssignments}
          icon={<FileText className="h-5 w-5" />}
          description="Assignments submitted"
        />
        <StatsCard
          title="Pending Assignments"
          value={stats.pendingAssignments}
          icon={<FileText className="h-5 w-5" />}
          description="Assignments due soon"
          highlight={stats.pendingAssignments > 0}
        />
        <StatsCard
          title="Average Grade"
          value={`${stats.averageGrade}%`}
          icon={<FileText className="h-5 w-5" />}
          description="Your overall performance"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>My Courses</CardTitle>
            <CardDescription>Courses you're enrolled in</CardDescription>
          </CardHeader>
          <CardContent>
            {courses.length > 0 ? (
              <div className="space-y-2">
                {courses.slice(0, 5).map((course) => (
                  <Link
                    key={course._id}
                    href={`/dashboard/courses/${course._id}`}
                    className="flex items-center p-2 rounded-md hover:bg-muted"
                  >
                    <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center mr-3">
                      <BookOpen className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{course.title}</p>
                      <p className="text-xs text-muted-foreground">{course.teacher.name}</p>
                    </div>
                  </Link>
                ))}

                {courses.length > 5 && (
                  <Link
                    href="/dashboard/courses"
                    className="block text-center text-sm text-primary hover:underline pt-2"
                  >
                    View all courses
                  </Link>
                )}
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground mb-2">No courses found</p>
                <Link href="/dashboard/courses/browse" className="text-primary hover:underline">
                  Browse available courses
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Assignments</CardTitle>
            <CardDescription>Assignments due soon</CardDescription>
          </CardHeader>
          <CardContent>
            <UpcomingAssignments />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Announcements</CardTitle>
          <CardDescription>Latest updates from your courses</CardDescription>
        </CardHeader>
        <CardContent>
          <RecentAnnouncements />
        </CardContent>
      </Card>
    </div>
  )
}

function StatsCard({ title, value, icon, description, highlight = false }) {
  return (
    <Card className={highlight ? "border-amber-500" : ""}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  )
}

function UpcomingAssignments() {
  const [assignments, setAssignments] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchAssignments() {
      try {
        const data = await getUpcomingAssignments()
        setAssignments(data)
      } catch (error) {
        console.error("Error fetching assignments:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAssignments()
  }, [])

  if (isLoading) {
    return (
      <div className="space-y-2">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    )
  }

  if (assignments.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">No upcoming assignments</p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {assignments.map((assignment) => (
        <Link
          key={assignment._id}
          href={`/dashboard/courses/${assignment.course._id}/assignments/${assignment._id}`}
          className="flex items-center p-2 rounded-md hover:bg-muted"
        >
          <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center mr-3">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate">{assignment.title}</p>
            <div className="flex justify-between">
              <p className="text-xs text-muted-foreground">{assignment.course.title}</p>
              <p className="text-xs font-medium text-amber-600">
                Due {format(new Date(assignment.dueDate), "MMM d, yyyy")}
              </p>
            </div>
          </div>
        </Link>
      ))}

      <Link href="/dashboard/assignments" className="block text-center text-sm text-primary hover:underline pt-2">
        View all assignments
      </Link>
    </div>
  )
}

function RecentAnnouncements() {
  const [announcements, setAnnouncements] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchAnnouncements() {
      try {
        const data = await getAnnouncements()
        setAnnouncements(data)
      } catch (error) {
        console.error("Error fetching announcements:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAnnouncements()
  }, [])

  if (isLoading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-20 w-full" />
      </div>
    )
  }

  if (announcements.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">No recent announcements</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {announcements.map((announcement) => (
        <div key={announcement._id} className="p-3 rounded-md border">
          <div className="flex justify-between items-start mb-2">
            <div>
              <p className="font-medium">{announcement.course.title}</p>
              <p className="text-xs text-muted-foreground">{announcement.createdBy.name}</p>
            </div>
            <p className="text-xs text-muted-foreground">{format(new Date(announcement.createdAt), "MMM d, yyyy")}</p>
          </div>
          <p className="text-sm">{announcement.content}</p>
        </div>
      ))}

      <Link href="/dashboard/announcements" className="block text-center text-sm text-primary hover:underline pt-2">
        View all announcements
      </Link>
    </div>
  )
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-10 w-32" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <Skeleton className="h-5 w-24" />
              <Skeleton className="h-8 w-8 rounded-full" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-12 mb-1" />
              <Skeleton className="h-4 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {[1, 2].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-32 mb-1" />
              <Skeleton className="h-4 w-48" />
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

