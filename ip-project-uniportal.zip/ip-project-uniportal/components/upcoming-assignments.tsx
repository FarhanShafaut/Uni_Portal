"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { getUpcomingAssignments } from "@/lib/assignment-service"
import { format } from "date-fns"
import { CalendarClock } from "lucide-react"

export function UpcomingAssignments() {
  const [assignments, setAssignments] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchAssignments() {
      try {
        const data = await getUpcomingAssignments()
        setAssignments(data)
      } catch (error) {
        console.error("Error fetching assignments:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAssignments()
  }, [])

  if (isLoading) {
    return <p>Loading assignments...</p>
  }

  if (assignments.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">No upcoming assignments</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {assignments.slice(0, 3).map((assignment) => (
        <Link
          key={assignment._id}
          href={`/dashboard/courses/${assignment.course._id}/assignments/${assignment._id}`}
          className="flex items-start p-2 rounded-md hover:bg-muted"
        >
          <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center mr-3 mt-1">
            <CalendarClock className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="font-medium">{assignment.title}</p>
            <p className="text-xs text-muted-foreground mb-1">{assignment.course.title}</p>
            <div className="flex items-center">
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                Due {format(new Date(assignment.dueDate), "MMM d, yyyy")}
              </span>
            </div>
          </div>
        </Link>
      ))}
    </div>
  )
}

