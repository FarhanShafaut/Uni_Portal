"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { getUserCourses } from "@/lib/course-service"
import { getTeacherStats } from "@/lib/teacher-service"
import { getRecentSubmissions } from "@/lib/submission-service"
import { BookOpen, Users, FileText, Plus } from "lucide-react"
import { format } from "date-fns"

export function TeacherDashboard() {
  const [courses, setCourses] = useState([])
  const [stats, setStats] = useState({
    totalStudents: 0,
    totalCourses: 0,
    totalAssignments: 0,
    pendingGrading: 0,
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        const [coursesData, statsData] = await Promise.all([getUserCourses(), getTeacherStats()])

        setCourses(coursesData)
        setStats(statsData)
      } catch (error) {
        console.error("Error fetching teacher dashboard data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  if (isLoading) {
    return <DashboardSkeleton />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Teacher Dashboard</h1>
        <Link href="/dashboard/courses/create">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Create Course
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Students"
          value={stats.totalStudents}
          icon={<Users className="h-5 w-5" />}
          description="Students enrolled in your courses"
        />
        <StatsCard
          title="Total Courses"
          value={stats.totalCourses}
          icon={<BookOpen className="h-5 w-5" />}
          description="Courses you're teaching"
        />
        <StatsCard
          title="Total Assignments"
          value={stats.totalAssignments}
          icon={<FileText className="h-5 w-5" />}
          description="Assignments created"
        />
        <StatsCard
          title="Pending Grading"
          value={stats.pendingGrading}
          icon={<FileText className="h-5 w-5" />}
          description="Submissions to grade"
          highlight={stats.pendingGrading > 0}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>My Courses</CardTitle>
            <CardDescription>Courses you're teaching</CardDescription>
          </CardHeader>
          <CardContent>
            {courses.length > 0 ? (
              <div className="space-y-2">
                {courses.slice(0, 5).map((course) => (
                  <Link
                    key={course._id}
                    href={`/dashboard/courses/${course._id}`}
                    className="flex items-center p-2 rounded-md hover:bg-muted"
                  >
                    <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center mr-3">
                      <BookOpen className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{course.title}</p>
                      <p className="text-xs text-muted-foreground">{course.students?.length || 0} students</p>
                    </div>
                  </Link>
                ))}

                {courses.length > 5 && (
                  <Link
                    href="/dashboard/courses"
                    className="block text-center text-sm text-primary hover:underline pt-2"
                  >
                    View all courses
                  </Link>
                )}
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground mb-2">No courses found</p>
                <Link href="/dashboard/courses/create" className="text-primary hover:underline">
                  Create your first course
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Submissions</CardTitle>
            <CardDescription>Recent assignment submissions from students</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentSubmissions />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function StatsCard({ title, value, icon, description, highlight = false }) {
  return (
    <Card className={highlight ? "border-amber-500" : ""}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  )
}

function RecentSubmissions() {
  const [submissions, setSubmissions] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchSubmissions() {
      try {
        const data = await getRecentSubmissions()
        setSubmissions(data)
      } catch (error) {
        console.error("Error fetching submissions:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchSubmissions()
  }, [])

  if (isLoading) {
    return (
      <div className="space-y-2">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    )
  }

  if (submissions.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">No recent submissions</p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {submissions.map((submission) => (
        <Link
          key={submission._id}
          href={`/dashboard/courses/${submission.assignment.course._id}/assignments/${submission.assignment._id}/submissions/${submission._id}`}
          className="flex items-center p-2 rounded-md hover:bg-muted"
        >
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate">{submission.assignment.title}</p>
            <div className="flex justify-between">
              <p className="text-xs text-muted-foreground">{submission.student.name}</p>
              <p className="text-xs text-muted-foreground">{format(new Date(submission.submittedAt), "MMM d, yyyy")}</p>
            </div>
          </div>
        </Link>
      ))}

      <Link href="/dashboard/submissions" className="block text-center text-sm text-primary hover:underline pt-2">
        View all submissions
      </Link>
    </div>
  )
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-10 w-32" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <Skeleton className="h-5 w-24" />
              <Skeleton className="h-8 w-8 rounded-full" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-12 mb-1" />
              <Skeleton className="h-4 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {[1, 2].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-32 mb-1" />
              <Skeleton className="h-4 w-48" />
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

