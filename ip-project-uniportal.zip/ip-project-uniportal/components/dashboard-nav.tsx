"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { LayoutDashboard, BookOpen, FileText, MessageSquare, Users, Settings } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

export function DashboardNav({ className }) {
  const pathname = usePathname()
  const { user } = useAuth()

  const isTeacher = user?.role === "teacher"

  const routes = [
    {
      href: "/dashboard",
      label: "Dashboard",
      icon: LayoutDashboard,
      active: pathname === "/dashboard",
    },
    {
      href: "/dashboard/courses",
      label: "Courses",
      icon: BookOpen,
      active: pathname.startsWith("/dashboard/courses"),
    },
    {
      href: "/dashboard/assignments",
      label: "Assignments",
      icon: FileText,
      active: pathname.startsWith("/dashboard/assignments"),
    },
    {
      href: "/dashboard/discussions",
      label: "Discussions",
      icon: MessageSquare,
      active: pathname.startsWith("/dashboard/discussions"),
    },
    ...(isTeacher
      ? [
          {
            href: "/dashboard/students",
            label: "Students",
            icon: Users,
            active: pathname.startsWith("/dashboard/students"),
          },
        ]
      : []),
    {
      href: "/dashboard/settings",
      label: "Settings",
      icon: Settings,
      active: pathname.startsWith("/dashboard/settings"),
    },
  ]

  return (
    <nav className={cn("hidden md:block w-64 p-6 border-r bg-background", className)}>
      <div className="space-y-1">
        {routes.map((route) => (
          <Button
            key={route.href}
            variant={route.active ? "secondary" : "ghost"}
            className={cn("w-full justify-start", route.active && "bg-secondary")}
            asChild
          >
            <Link href={route.href}>
              <route.icon className="mr-2 h-5 w-5" />
              {route.label}
            </Link>
          </Button>
        ))}
      </div>
    </nav>
  )
}

