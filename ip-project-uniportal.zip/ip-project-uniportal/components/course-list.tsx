"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { getUserCourses } from "@/lib/course-service"
import { BookOpen } from "lucide-react"

export function CourseList() {
  const [courses, setCourses] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchCourses() {
      try {
        const data = await getUserCourses()
        setCourses(data)
      } catch (error) {
        console.error("Error fetching courses:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCourses()
  }, [])

  if (isLoading) {
    return <p>Loading courses...</p>
  }

  if (courses.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground mb-2">No courses found</p>
        <Link href="/dashboard/courses" className="text-primary hover:underline">
          Browse courses
        </Link>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {courses.slice(0, 3).map((course) => (
        <Link
          key={course._id}
          href={`/dashboard/courses/${course._id}`}
          className="flex items-center p-2 rounded-md hover:bg-muted"
        >
          <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center mr-3">
            <BookOpen className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate">{course.title}</p>
            <p className="text-xs text-muted-foreground">{course.teacher.name}</p>
          </div>
        </Link>
      ))}

      {courses.length > 3 && (
        <Link href="/dashboard/courses" className="block text-center text-sm text-primary hover:underline pt-2">
          View all courses
        </Link>
      )}
    </div>
  )
}

