"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { BookOpen, Calendar, FileText, Home, LogOut, MessageSquare, Settings, User } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

export function Sidebar() {
  const pathname = usePathname()
  const { logout, user } = useAuth()

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: Home },
    { href: "/dashboard/courses", label: "Courses", icon: BookOpen },

    { href: "/dashboard/assignments", label: "Assignments", icon: FileText },
    { href: "/dashboard/announcements", label: "Announcements", icon: Calendar },
    { href: "/dashboard/discussions", label: "Discussions", icon: MessageSquare },
    { href: "/dashboard/profile", label: "Profile", icon: User },
    { href: "/dashboard/settings", label: "Settings", icon: Settings },
  ]

  return (
    <div className="flex h-screen w-64 flex-col border-r bg-card">
      <div className="p-4">
        <h2 className="text-lg font-bold">University Portal</h2>
        {user && (
          <p className="text-sm text-muted-foreground mt-1">
            {user.name} ({user.role})
          </p>
        )}
      </div>
      <nav className="flex-1 space-y-1 p-2">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center rounded-md px-3 py-2 text-sm font-medium",
              pathname === item.href
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-muted hover:text-foreground",
            )}
          >
            <item.icon className="mr-2 h-4 w-4" />
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="border-t p-4">
        <button
          onClick={logout}
          className="flex w-full items-center rounded-md px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          onClick={logout}
          className="flex w-full items-center rounded-md px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <LogOut className="mr-2 h-4 w-4" />
  )
}

