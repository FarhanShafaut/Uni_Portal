"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { getAnnouncements } from "@/lib/announcement-service"
import { formatDistanceToNow } from "date-fns"

export function AnnouncementList() {
  const [announcements, setAnnouncements] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchAnnouncements() {
      try {
        const data = await getAnnouncements()
        setAnnouncements(data)
      } catch (error) {
        console.error("Error fetching announcements:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAnnouncements()
  }, [])

  if (isLoading) {
    return <p>Loading announcements...</p>
  }

  if (announcements.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground">No announcements</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {announcements.slice(0, 3).map((announcement) => (
        <Link
          key={announcement._id}
          href={`/dashboard/courses/${announcement.course._id}/announcements/${announcement._id}`}
          className="block p-2 rounded-md hover:bg-muted"
        >
          <div className="flex items-center justify-between mb-1">
            <p className="font-medium text-sm">{announcement.course.title}</p>
            <p className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(announcement.createdAt), { addSuffix: true })}
            </p>
          </div>
          <p className="text-sm line-clamp-2">{announcement.content}</p>
        </Link>
      ))}
    </div>
  )
}

