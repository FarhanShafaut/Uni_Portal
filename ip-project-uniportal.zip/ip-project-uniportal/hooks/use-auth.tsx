"use client"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { getCurrentUser, logoutUser } from "@/lib/auth-service"
import { useToast } from "@/hooks/use-toast"

// Define the User type
type User = {
  _id: string
  name: string
  email: string
  role: "student" | "teacher"
  profileImage?: string
}

// Define the AuthContext type
type AuthContextType = {
  user: User | null
  isLoading: boolean
  logout: () => Promise<void>
  isTeacher: boolean
  isStudent: boolean
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()
  const { toast } = useToast()

  async function loadUser() {
    try {
      const { success, user } = await getCurrentUser()

      if (success && user) {
        setUser(user)
      } else if (pathname.startsWith("/dashboard")) {
        // Redirect to login if not authenticated and trying to access dashboard
        router.push("/login")
      }
    } catch (error) {
      console.error("Error loading user:", error)
      if (pathname.startsWith("/dashboard")) {
        router.push("/login")
      }
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadUser()
  }, [pathname])

  const refreshUser = async () => {
    await loadUser()
  }

  const logout = async () => {
    try {
      await logoutUser()
      setUser(null)
      toast({
        title: "Logged out",
        description: "You have been logged out successfully.",
      })
      router.push("/login")
    } catch (error) {
      console.error("Error logging out:", error)
      toast({
        title: "Error",
        description: "Failed to log out. Please try again.",
        variant: "destructive",
      })
    }
  }

  const isTeacher = user?.role === "teacher"
  const isStudent = user?.role === "student"

  return (
    <AuthContext.Provider value={{ user, isLoading, logout, isTeacher, isStudent, refreshUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)

  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }

  return context
}

